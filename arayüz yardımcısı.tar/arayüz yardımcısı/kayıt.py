#!/usr/bin/env python3
#-*- coding: utf8 -*-

import tkinter,json,shutil,tkinter.messagebox,subprocess
from tkinter.filedialog import*

global kaydedildi,sbky

# subprocess.call(["sed", "-i", 's/\<bbb\>/bbbx/g', '/home/suha/Masaüstü/ppp/pppform.pyyedek'])
# subprocess.call(["sed", "-i", 's/\<'+eski+'\>/'+yeni+'/g', y]

def formkayıt(adres,eskiad,yeniad):#form adını değiştirmek için
	yol=adres
	subprocess.call(["sed", "-i", 's/\<'+eskiad+'\>/'+yeniad+'/g', yol])#başka türlü olmuyor!!!
	# bu şekilde sadece tam kelimeler değişti. Tümünü değiştirmek için '\<' ve '\>' işaretlerini kaldır.

def prgkay(fls,komutlar):#düğme komutlarını program dosyasına kaydet
	pryol=os.path.dirname(fls);yol=""
	dsliste=os.listdir(pryol)
	dsliste=[pryol+"/"+x for x in dsliste if os.path.isfile(x)]#bu dizindeki dosyalar ve yolları
	for a in dsliste:
		with open(a,"r") as ds:
			for i in range(10):
				met=ds.readline()
				if "program_adı:" in met:
					ds.seek(0);iç=ds.readlines()
					for n in iç:
						if "program_adı" in n:sn=iç.index(n)+2;yol=a;break
					iç.insert(sn,"\n")
					for n in iç:
						if "lütfen silmeyiniz" in n:
							sn2=iç.index(n);iç.insert(sn2,"\n");break
					for i in range(1,len(komutlar),2):
						if "def "+komutlar[i]+"():\n" not in iç:
							iç.insert(sn,"def "+komutlar[i]+"():\n"+"\tpass\n")
					for i in range(0,len(komutlar),2):
						if komutlar[i]+"['command']="+komutlar[i+1]+"\n" not in iç:
							iç.insert(sn2,komutlar[i]+"['command']="+komutlar[i+1]+"\n")
					break
				else:return

	# print(komutlar,iç)
	with open(yol,"w") as ds:
		for s in iç:
			ds.writelines(s)


def kaydet(*args):#olayın en babayiğit bölümü!!
	global pencere,secis,kaydedildi,resimyol,sbky
	pencere=args[0];secis=args[1];adres=args[2];kaydedildi=args[3];arlb=args[4]
	resimyol=args[5];ipu=args[6];sbky=args[7];komutlar=[]
	if adres.get()=="":#adres çubuğu boş ise
		fls=asksaveasfilename(title="Kaydedilecek dosya adı",defaultextension="form.py",filetypes=[("Tüm dosyalar",("*.*"))])
		if fls=="" or fls==(): return
		ds=open(fls+"tmp","w")
	else:
		fls=adres.get();ds=open(fls+"tmp","w")
	try:
		formdiz=[];n=pencere.winfo_children()#önce toplevel olanlar.
		haricler=[u"Araçlar",u"Araç Çubuğu",u"arayüz tasarımı"];p=os.path.dirname(fls)
		haric=["width","height","class","use","screen","container","colormap","visual"]
		for a in n:
			awc= a.winfo_class()
			if awc=="Entry" or awc=="Listbox" or awc=="Label": continue
			i=a.title()
			if i not in haricler: formdiz.append(n[(n.index(a))])#;print(formdiz)
		bs="#!/usr/bin/env python3\n#-*- coding: utf8 -*-\nfrom tkinter import*\nfrom tkinter.scrolledtext import ScrolledText\n"
		bs+="from tkinter.scrolledlist import*\nfrom tkinter.ttk  import Combobox\n"
		bs+="from tkinter import wcktooltips\nfrom PIL import ImageTk\n\n"
		bs+="pencere=Toplevel()\n"
		ds.write(bs)
		for a in formdiz:
			pencere.update();a.update_idletasks()#;geo=a.winfo_geometry();a.lift()
			geo=a.wm_geometry();a.lift();ovre=a.overrideredirect();res=a.wm_iconbitmap()
			if ovre==None:ovre=0
			kl=[];vl=[];i=a.title();ad=a.winfo_name();cl=a.winfo_class()
#--------# print (geo,type(a.winfo_x()))#--type=int, burası önemli
			#önce mevcut ayarlardan geçerli olanı alıp sözlük oluştur
			for k in a.keys():#bunu ayıkla--hariçlere göre
				if k not in haric and (str(a[k]))!="":
					kl.append(k);vl.append(str(a[k]))#şimdi elimizde iki dizi var
			ayar=dict(zip(kl,vl))
			ds.write((ad)+"="+cl+"(pencere,");json.dump(ayar,ds);ds.write(",name="+"'"+ad+"'"+")")
			ds.write("\n"+ad+".title"+"('"+i+"')")
			ds.write("\n"+ad+".geometry('"+geo+"')")
			ds.write("\n"+ad+".resizable("+",".join(map(str,(a.resizable())))+")")
			ds.write("\n"+ad+".overrideredirect("+str(ovre)+")")
			ds.write("\n"+ad+".wm_iconbitmap("+"'"+res+"')")

			ds.write("\n"*2)#;ds.write("vartr4="+"IntVar"+"\n")
			# print(ad)
	#**************************** Toplevel lar bitti. Şimdi diğer araçlar *******************************
		for a in formdiz:#her form için alt unsurları al
			ps=a.place_slaves()#;print(ps)
			for cd in ps:
				cdn=cd.winfo_name()
				if cd in secis or cdn[:4]=="_iss":continue#seçme işaretlerini kaydetme
				ss=(cd.__dict__)["children"]
				cdsnf=cd.winfo_class()
				if len(ss)>0 and cdsnf=="Frame" and cdsnf!="OptionMenu":
					cs=cd.winfo_children()[len(ss)-1]
					cl=cd.winfo_children()[len(ss)-1].__class__.__name__
					adcd=cd.winfo_children()[len(ss)-1].winfo_name()
					cd=cs
				else:
					adcd=cd.winfo_name();cl=cd.__class__.__name__
				kl=[];vl=[];ad=a.winfo_name();ism=cd.winfo_name()
				dp=cd.place_info()
				cdx=dp["x"];cdy=dp["y"];cdw=dp["width"];cdh=dp["height"]
				cdke=cd.keys()
				if cl=="Scrollbar":cdke=sbky
				if cl=="Canvas":cdke=cd.config().keys()
				for k in cdke:
					if k=="class" or k=="image":continue
					deger=str(cd[k])
					if deger!="" and k=="command":komutlar.append(adcd);komutlar.append(deger)
					if deger!="": kl.append(k);vl.append(deger)#iki listemiz oldu
				ayar=dict(zip(kl,vl))
				if cl=="ScrolledText" or cl=="ScrolledList":
					ds.write(adcd+"="+cl+"("+ad+",name="+'"'+adcd+'"');ds.write(")")
					ds.write("\n"+adcd+".place("+"x="+cdx+",y="+cdy+",width="+cdw+",height="+cdh+")")
					ds.write("\n"+"t=");json.dump(ayar,ds);ds.write("\n")
					ds.write("for a in t.keys():"+adcd+"[a]=t[a]")
					ds.write("\n"*2)
				else:
					ds.write(adcd+"="+cl+"("+ad+",")
					for i in range(len(kl)):
						deger=vl[i]
						if kl[i]=="from": kl[i]="from_"
						if kl[i]=="values":
							ds.write("values=")
							json.dump(cd["values"],ds);ds.write(",")#böyle de yazdırılıyor#ds.write(deger);ds.write(",")
						else:
							if deger.isdigit()==True:
								deger=int(deger)
								ds.write(kl[i]+"=");json.dump(deger,ds);ds.write(",")
							else:
								ds.write(kl[i]+"="+'"'+deger+'"'+",")#asıl satır
					ds.write("name="+"'"+ism+"'"+")")
					ds.write("\n"+adcd+".place("+"x="+cdx+",y="+cdy+",width="+cdw+",height="+cdh+")")
					if "image" in cd.keys():#özelliklerde resim var mı?
						if cd["image"]!="":#resim varsa bunla ilgili öğeleri ekle
							ir=resimyol[resimyol.index(adcd)+1]
							ds.write("\nrr=ImageTk.PhotoImage(file=u"+"'"+ir+"'"+")\n")
							ds.write(adcd+"['image']=rr;");ds.write(adcd+".image=rr\n")
					ds.write("\n"*2)
	# araçlar bitti. Menü çubukları için ayrı işlem yapmak gerek!
			# pencere adı-menü çubuğu adı-önalan-artalan-a,["aa,zz"]-w,["ww"]
		for f in formdiz:
			fc=f.winfo_children();menüler=[]
			for i in fc:
				if "Menu" in i.winfo_class():
					menüler.append(i)#eğer menü varsa yazalım.
					mç=menüler[0]
					menü_çubuğu=[mç.winfo_name()]
					sn=mç.index("end");tf=mç["tearoff"]
					for a in range(tf,sn+1):menü_çubuğu.append(mç.entrycget(a,"label"))
					dl=[str(mç["bg"]),str(mç["fg"]),mç["tearoff"],str(mç["font"])]
					menü_çubuğu.extend(dl)
					ds.write("\n")
					yz="menubar=Menu("+f.winfo_name()+",name="+"'"+menü_çubuğu[0]+"'"
					yz+=",bg='"+menü_çubuğu[-4]+"'"+",fg='"+menü_çubuğu[-3]+"'"+",tearoff="+str(menü_çubuğu[-2])+",font='"+menü_çubuğu[-1]+"'"
# menü çubuğunu yazdık. şimdi alt etiketleri yaz.
					ds.write(yz+")"+"\n")
					ds.write(f.winfo_name()+".config(menu=menubar)"+"\n")
					mç_alt=mç.winfo_children()
					for s,m in enumerate(mç_alt,1):
						n = [menü_çubuğu[s]]
						nn = [str(m["bg"]), str(m["fg"]), m["tearoff"], str(m["font"])]
						sn = m.index("end")  # alt öğede kaç giriş var?
						#tearoff çizgisi de öğe sayılıyor-Dikkat!!
						for i in range(m["tearoff"], sn + 1): n.append(m.entrycget(i, "label"))#alt öğeler
						n.extend(nn)
						iöz=",bg="+"'"+n[-4]+"'"+",fg="+"'"+n[-3]+"'"+",tearoff="+str(n[-2])+",font="+"'"+n[-1]+"')"
						ds.write(n[0]+"=Menu(menubar"+",name="+"'"+n[0]+"'"+iöz+"\n")
						ds.write("menubar.add_cascade(label="+"'"+n[0]+"'"+",menu="+n[0]+")\n")
						km=n[1:-4];ukm=len(km)
						for i in range(ukm):
							ds.write(n[0]+".add_command(label="+"'"+km[i]+"'"+")\n")
						ds.write("\n")
					# menü varsa bitti. Geçiniz...daha alt menüler için düzenleme gerek!!
		arlbdiz=[];arb=arlb.size()#tablar için
		for dd in range(arb):
			d=str(arlb.get(dd).split("--")[0])
			if d.isdigit()==True:d="om"+d[-2:]
			arlbdiz.append(d)
		if arb==0:#araç listesi boş ve dolayısıyla tab yoksa
			ds.write("\n");ds.write("tabsr=()")
		else:
			ds.write("tabsr="+"("+','.join(arlbdiz)+",)")#böyle de yazdırılıyor

		ds.write("\n"+"for wi in tabsr:\n")
		ds.write("\t"+"sn=wi.winfo_class()\n")
		ds.write("\t"+"if sn=='Canvas':continue\n")
		ds.write("\twi.lift()");ds.write("\n\n")
		ds.write("def sra(event):\n");ds.write("\tw=event.widget\n")
		ds.write("\tsnf=w.winfo_class()\n");ds.write("\tif snf=='Panedwindow':return 'break'\n")
		ds.write('\tif w["takefocus"]==0:w.tk_focusNext().focus()\n')
		ds.write('\treturn "break"\n');iad=formdiz[0].winfo_name()
		ds.write(iad+'.bind("<FocusIn>",sra)\n\n')
		if len(resimyol)==0:#resim listesi boş mu?
			ds.write("resimyol=[]\n")
		else:
			ds.write("resimyol="+"['"+"','".join(resimyol)+"']")#böyle de yazdırılıyor
			ds.write("\n\n")
		ipu2={}
		for k,v in ipu.items():#ipuçlarındaki boş öğeleri at
			if v!="":ipu2.update({k:v})#boş olmayanları buraya at
		if len(ipu2)>0:
			for k,v in ipu2.items():
				ds.write("wcktooltips.register("+k+","+"'"+v+"'"+")"+"\n")
			ipuclar=ipu2;ds.write("ipuclar=");json.dump(ipuclar,ds)
#ensure_ascii=False,encoding="utf-8")
		else:
			ipuclar=ipu2;ds.write("ipuclar={}")
		ds.write("\n\npencere.withdraw()")
		ds.close()#oldu---en sona koy
		dy=os.path.abspath(fls+"tmp")
	except Exception as inst:#hata oluşursa dosyayı bozmadan olduğu gibi bırak ve çık
		# print (inst,type(inst))#hata kodu ve sınıfı
		print(inst.args[0])
		pcc=pencere.winfo_children()
		for p in pcc:p.withdraw()
		hm=tkinter.messagebox.showwarning("Dikkat! Hata","Dosya kaydedilemedi.\nHatayı düzeltip tekrar deneyiniz.\n Açıklama: "+inst.args[0])
		for p in pcc:p.deiconify()
		os.remove(fls+"tmp")
	else:
		if os.path.exists(fls):#sadece form açılırsa gerekli.
			os.remove(fls);os.rename(dy,fls)
		else:
			os.rename(dy,fls)
		shutil.copyfile(fls,(fls+"yedek"))#ayrıca yedek bir form da kaydedilir.
		prgkay(fls,komutlar)
		kaydedildi=True
		for p in formdiz:p.withdraw();p.update()
		hm=tkinter.messagebox.showinfo("Kayıt bitti!","Dosya başarıyla kaydedildi.")
		# for p in pcc:p.deiconify()
		for p in formdiz:p.deiconify()
		return kaydedildi






