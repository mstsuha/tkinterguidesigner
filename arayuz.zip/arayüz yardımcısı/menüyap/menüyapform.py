#!/usr/bin/env python3
#-*- coding: utf8 -*-
from tkinter import*
from tkinter.scrolledtext import ScrolledText
from tkinter.scrolledlist import*
from tkinter.ttk  import Combobox
from tkinter import wcktooltips
from PIL import ImageTk

pencere=Toplevel()
men_yap=Toplevel(pencere,{"padx": "0", "pady": "0", "borderwidth": "0", "relief": "solid", "highlightthickness": "0", "highlightcolor": "#000000", "bg": "#d9d9d9", "highlightbackground": "#d9d9d9", "background": "#d9d9d9", "takefocus": "1", "bd": "0"},name='men_yap')
men_yap.geometry('650x580+372+79')
men_yap.title('Menü Oluşturma Ve Düzenleme')

etkf=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="font",underline="-1",width=0,wraplength=0,name='etkf')
etkf.place(x=519,y=270,width=120,height=20)

etkte=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="tear off",underline="-1",width=0,wraplength=0,name='etkte')
etkte.place(x=454,y=270,width=52,height=20)

etkhrf=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Önalan",underline="-1",width=0,wraplength=0,name='etkhrf')
etkhrf.place(x=362,y=270,width=80,height=20)

etkart=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Artalan",underline="-1",width=0,wraplength=0,name='etkart')
etkart.place(x=270,y=270,width=80,height=20)

etkyıldız=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="pink",bd=1,bg="pink",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="red",font="Ubuntu 12 bold",foreground="red",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="***************************** alt menüler *********************************",underline="-1",width=0,wraplength=0,name='etkyıldız')
etkyıldız.place(x=10,y=245,width=618,height=20)

fon=Entry(men_yap,background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,cursor="xterm",disabledbackground="#d9d9d9",disabledforeground="#a3a3a3",exportselection=1,fg="#000000",font="TkTextFont",foreground="#000000",highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,insertbackground="#000000",insertborderwidth=0,insertofftime=300,insertontime=600,insertwidth=2,justify="left",readonlybackground="#d9d9d9",relief="sunken",selectbackground="#c3c3c3",selectborderwidth=0,selectforeground="#000000",state="normal",takefocus=1,textvariable="yeni",validate="none",width=20,name='fon')
fon.place(x=195,y=152,width=228,height=20)

etkfon=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Font :",underline="-1",width=0,wraplength=0,name='etkfon')
etkfon.place(x=150,y=152,width=43,height=20)

etkteo=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="tearoff (0-1) :",underline="-1",width=0,wraplength=0,name='etkteo')
etkteo.place(x=10,y=152,width=88,height=20)

teof=Entry(men_yap,background="#ffffff",bd=1,bg="#ffffff",borderwidth=1,cursor="xterm",disabledbackground="#d9d9d9",disabledforeground="#a3a3a3",exportselection=1,fg="#000000",font="TkTextFont",foreground="#000000",highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,insertbackground="#000000",insertborderwidth=0,insertofftime=300,insertontime=600,insertwidth=2,justify="center",readonlybackground="#d9d9d9",relief="sunken",selectbackground="#c3c3c3",selectborderwidth=0,selectforeground="#000000",state="normal",takefocus=1,validate="none",width=20,name='teof')
teof.place(x=106,y=152,width=32,height=20)

ck=Button(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,command="sys.exit",compound="none",default="disabled",disabledforeground="#a3a3a3",fg="#ec0000",font="TkDefaultFont 12 bold",foreground="#ec0000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,justify="center",padx="3m",pady="1m",relief="raised",repeatdelay=0,repeatinterval=0,state="normal",takefocus=1,text="Bitti",underline="-1",width=0,wraplength=0,name='ck')
ck.place(x=29,y=522,width=52,height=30)

bas=Button(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#6ca1f0",bd=1,bg="#6ca1f0",borderwidth=1,compound="none",default="disabled",disabledforeground="#a3a3a3",fg="#b41100",font="TkDefaultFont",foreground="#b41100",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,justify="center",padx="3m",pady=0,relief="raised",repeatdelay=0,repeatinterval=0,state="normal",takefocus=1,text="alt menüler için basınız",underline="-1",width=0,wraplength=0,name='bas')
bas.place(x=410,y=209,width=167,height=28)

misim=Entry(men_yap,background="#ffffff",bd=1,bg="#ffffff",borderwidth=1,cursor="xterm",disabledbackground="#d9d9d9",disabledforeground="#a3a3a3",exportselection=1,fg="#000000",font="TkTextFont",foreground="#000000",highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,insertbackground="#000000",insertborderwidth=0,insertofftime=300,insertontime=600,insertwidth=2,justify="left",readonlybackground="#d9d9d9",relief="sunken",selectbackground="#c3c3c3",selectborderwidth=0,selectforeground="#000000",state="normal",takefocus=1,validate="none",width=20,name='misim')
misim.place(x=132,y=120,width=100,height=20)

yap=Button(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",default="disabled",disabledforeground="#a3a3a3",fg="#000000",font="Ubuntu 12",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,justify="center",padx="3m",pady="1m",relief="raised",repeatdelay=0,repeatinterval=0,state="normal",takefocus=1,text="menüyü oluştur",underline="-1",width=0,wraplength=65,name='yap')
yap.place(x=517,y=502,width=100,height=52)

pisim=Combobox(men_yap,height=10,exportselection=1,font="TkTextFont",justify="left",state="normal",validate="none",width=20,background="#006400",takefocus=1,name='pisim')
pisim.place(x=257,y=48,width=102,height=20)

etkmad=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#0000c8",font="TkDefaultFont 12 bold",foreground="#0000c8",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Menü çubuğunun özellikleri:",underline="-1",width=0,wraplength=0,name='etkmad')
etkmad.place(x=10,y=84,width=611,height=26)

etkmp=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Menü oluşturulacak formun adı:",underline="-1",width=0,wraplength=0,name='etkmp')
etkmp.place(x=10,y=48,width=248,height=20)

mtür=Combobox(men_yap,height=10,values=["cascade", "popup"],exportselection=1,font="TkTextFont",justify="left",state="active",textvariable="value",validate="none",width=20,background="#006400",takefocus=1,name='mtür')
mtür.place(x=483,y=48,width=80,height=20)

etkmtür=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Menü türü:",underline="-1",width=0,wraplength=0,name='etkmtür')
etkmtür.place(x=400,y=48,width=72,height=20)

etkler=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Menü çubuğunda görünecek etiketleri virgülle ayırarak yazın:",underline="-1",width=0,wraplength=0,name='etkler')
etkler.place(x=10,y=184,width=380,height=20)

etklerad=Entry(men_yap,background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,cursor="xterm",disabledbackground="#d9d9d9",disabledforeground="#a3a3a3",exportselection=1,fg="#000000",font="Ubuntu 10 bold",foreground="#000000",highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,insertbackground="#000000",insertborderwidth=0,insertofftime=300,insertontime=600,insertwidth=2,justify="left",readonlybackground="#d9d9d9",relief="sunken",selectbackground="#c3c3c3",selectborderwidth=0,selectforeground="#000000",state="normal",takefocus=1,validate="none",width=20,name='etklerad')
etklerad.place(x=10,y=209,width=380,height=28)

etkad=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Menü Çubuğu Adı:",underline="-1",width=0,wraplength=0,name='etkad')
etkad.place(x=10,y=120,width=114,height=20)

etkbk=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Artalan rengi:",underline="-1",width=0,wraplength=0,name='etkbk')
etkbk.place(x=243,y=120,width=88,height=20)

etkfg=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="w",background="#90ee90",bd=1,bg="#90ee90",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="#000000",font="TkDefaultFont",foreground="#000000",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Harf rengi:",underline="-1",width=0,wraplength=0,name='etkfg')
etkfg.place(x=447,y=120,width=76,height=20)

mbg=Entry(men_yap,background="#ffffff",bd=1,bg="#ffffff",borderwidth=1,cursor="xterm",disabledbackground="#d9d9d9",disabledforeground="#a3a3a3",exportselection=1,fg="#000000",font="TkTextFont",foreground="#000000",highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,insertbackground="#000000",insertborderwidth=0,insertofftime=300,insertontime=600,insertwidth=2,justify="left",readonlybackground="#d9d9d9",relief="sunken",selectbackground="#c3c3c3",selectborderwidth=0,selectforeground="#000000",state="normal",takefocus=1,validate="none",width=20,name='mbg')
mbg.place(x=335,y=120,width=100,height=20)

mfg=Entry(men_yap,background="#ffffff",bd=1,bg="#ffffff",borderwidth=1,cursor="xterm",disabledbackground="#d9d9d9",disabledforeground="#a3a3a3",exportselection=1,fg="#000000",font="TkTextFont",foreground="#000000",highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=1,insertbackground="#000000",insertborderwidth=0,insertofftime=300,insertontime=600,insertwidth=2,justify="left",readonlybackground="#d9d9d9",relief="sunken",selectbackground="#c3c3c3",selectborderwidth=0,selectforeground="#000000",state="normal",takefocus=1,validate="none",width=20,name='mfg')
mfg.place(x=524,y=120,width=100,height=20)

etkuyar=Label(men_yap,activebackground="#ececec",activeforeground="#000000",anchor="center",background="pink",bd=1,bg="pink",borderwidth=1,compound="none",disabledforeground="#a3a3a3",fg="red",font="Ubuntu 14 bold",foreground="red",height=0,highlightbackground="#d9d9d9",highlightcolor="#000000",highlightthickness=0,justify="center",padx=1,pady=1,relief="flat",state="normal",takefocus=0,text="Lütfen bütün bölümleri doldurunuz!",underline="-1",width=0,wraplength=0,name='etkuyar')
etkuyar.place(x=10,y=10,width=618,height=20)

tabsr=(pisim,mtür,misim,mbg,mfg,teof,fon,etklerad,bas,yap,ck,etkfg,etkmtür,etkler,etkmad,etkteo,etkuyar,etkyıldız,etkart,etkhrf,etkte,etkf,)
for wi in tabsr:
	sn=wi.winfo_class()
	if sn=='Canvas':continue
	wi.lift()

def sra(event):
	w=event.widget
	snf=w.winfo_class()
	if snf=='Panedwindow':return 'break'
	if w["takefocus"]==0:w.tk_focusNext().focus()
	return "break"
men_yap.bind("<FocusIn>",sra)

resimyol=[]
wcktooltips.register(fon,'Font seçici için Ctrl+sol tık.')
wcktooltips.register(mbg,'Renk seçmek için Ctrl+sol tık.')
wcktooltips.register(mfg,'Renk seçmek için Ctrl+sol tık.')
ipuclar={"fon": "Font se\u00e7ici i\u00e7in Ctrl+sol t\u0131k.", "mbg": "Renk se\u00e7mek i\u00e7in Ctrl+sol t\u0131k.", "mfg": "Renk se\u00e7mek i\u00e7in Ctrl+sol t\u0131k."}

pencere.withdraw()
