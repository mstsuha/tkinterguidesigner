#!/usr/bin/env python3
#-*- coding: utf8 -*-
import getpass,sys,os,json
kul=getpass.getuser()
sys.path.append(os.getcwd())
from menüyap.menüyapform import*

değerler=[]
pencereadları=[]
# n=pencere.winfo_children()

# for p in n:#pencere adlarını bul
# 	if p.winfo_class()=="Toplevel":
# 		pencereadları.append(p.winfo_name())

# pisim["values"]=pencereadları
# pisim.insert(0,pisim["values"][0])
# mtür.insert(0,mtür["values"][0])
# pisim.focus()

def komutyap(pr):
	pass

def seç(event):
	w=event.widget;menüler=[]
	cn=form1.winfo_children()
	for i in cn:
		if i.winfo_class()=="Menu":
			cm=(i.__dict__)["children"]
			for a in cm.keys():
				menüler.append(cm[a])
			#for a in menüler:
				#print(a.__dict__)

def dizi(event=None):
	f=(form1.__dict__)["children"];al=etklerad.get();x=10;y=140
	if al!="":l1=etklerad.get().split(",")
	if len(l1)>0:#liste boş değilse etiket ve girişleri oluştur.
		for a in l1:
			if a in f:f[a].destroy()
			eta="et"+str(l1.index(a))#öncekileri sil
			if eta in f:f[eta].destroy()
			et=Label(form1,text=a,name=eta);et.place(x=x,y=y)
			el=Entry(form1,name="_"+a);el.place(x=x+60,y=y,width=180,height=20)#isimleri değiştir
			y+=25

def menüçubuğu(event=None):
	mad=pisim.get().strip();etiketler=(etklerad.get().strip()).split(",");komut=[]
	pr=n[pencereadları.index(mad)]
	menubar=Menu(pr,bg="red",font="ubuntu 12",name=misim.get().strip())
	değerler.append(pr);değerler.append(misim.get().strip())
	pr.config(menu=menubar)#menü çubuğu görüntülensin
	for w in etiketler:#ana etiketleri oluştur
		m1 = Menu(menubar, tearoff=0,bg="green",name=w)
		menubar.add_cascade(label=w, menu=m1)
		pr.update()
	for e in etiketler:#önce alt menü komutlarını oku
		komut=(pr.__dict__)["children"]["_"+e].get().split(",")#komut listesini al
		değerler.append(e);değerler.append(komut)
		for k in komut:
			kw=(menubar.__dict__)["children"][e]
			kw.add_command(label=k)
	pr.update()
	#print(değerler)
	with open ("değeryaz","w") as ds:
		u=len(değerler)
		ds.write("pencere:"+değerler[0].winfo_name()+"\n"+"menü çubuğu adı:"+değerler[1]+"\n")
		for a in range(2,u,2):
			ds.write(değerler[a]+",")
			json.dump(değerler[a+1],ds);ds.write("\n")

# yap["command"]=menüçubuğu
# bas["command"]=dizi
# bas.bind("<Return>",dizi)
# yap.bind("<Return>",menüçubuğu)
# ck["command"]=sys.exit


#******* lütfen silmeyiniz **********
p=pencere.winfo_parent()
wn=pencere._nametowidget(p);wn.withdraw()
mainloop()
