#!/usr/bin/env python3
#-*- coding: utf-8 -*-

import tkinter.messagebox,importlib,kayıt
from tkinter.scrolledtext import ScrolledText
from scrolledlist import*
from tkinter.ttk  import Combobox
from tkinter import wcktooltips
from PIL import ImageTk
from tkinter.colorchooser import *
from tkinter.filedialog import *
from getpass import getuser
from codecs import *
from tkfontchooser import tkfontchooser

# ****************yol kontrol****************************
s_diz=os.getcwd()#önce burada kontrol et, önce dosyayı oku
n=os.listdir(s_diz)
if "anadizyol" in n:#varsa zaten o dizindesin
	anaprg_yol=s_diz;ana_dizin=s_diz
else:#bu dizinde yoksa, programın bulunduğu dizini bul, dosyayı da değiştir.
	y=os.popen("find /home -name 'arayüz yardımcısı' -type d -print 2>/dev/null").readline().strip()
	os.chdir(y);anaprg_yol=y;ana_dizin=y
	with open(y+"/anadizyol","w") as ds:
		ds.write(y+"/tkarayüz4.py")
#************** global değişkenler***************************
sonbas="";sayliste=[];secilen=[];ipu={};liste=("",);secis=[];mef=""
kaydedildi=True;resimyol=[];kursorlar=[];araçliste=[]
wad=""#seçenek düğmeleri için
kul=getuser();pb="arayüz tasarımı";vzgdeg=0
farklarx=[];farklary=[];w_ayar=[]
#******************pencereler ve çerçeveler*********************************
gf=Tk()#giriş formu
gf.title("Lütfen işleminizi seçiniz")
gf.geometry("450x200+325+95")#350
ds=open("sonyol");son_y=ds.readline().strip();ds.close()
sec0=Label(text="1. Sadece boş bir form oluştur",fg="dark red")
sec0.place(x=10,y=10)
sec1=Label(text="2. Varolan bir form dosyasını aç",fg="red");sec1.place(x=10,y=30)
sec2=Label(text="3. Yeni proje oluştur",fg="blue");sec2.place(x=10,y=50)
sec3=Label(text="4. Önceki projeyle devam et",fg="dark green")
sec3.place(x=10,y=70)
sec4=Label(text="Seçiminiz?").place(x=10,y=90)
g1=Entry(width=1);g1.place(x=80,y=90);g1.insert(END,"4");g1.focus()
g1.bind("<Key>",lambda event=None:g1.delete(0,END))
sec51=Label(text="("+son_y+")",anchor="w",bg="pink",wraplength=425)
sec51.place(x=10,y=155,height=40)
# sec51=Message(text="("+son_y+")",bg="blue",anchor="w",aspect=800).place(x=95,y=90,width=350)
sec5=Label(text="İstediğiniz seçenek üzerine tıklayınız veya\nseçiminizi giriniz.",justify="left")
sec5["text"]+=" Sonra 'Tamam' a tıklayınız."
sec5.place(x=10,y=120)
vzg=IntVar();vzg.set(0)

def al(event=None):#program başındaki seçim penceresi
	global secenek
	secenek=g1.get()
	if secenek!="1" and secenek!="2" and secenek!="3" and secenek!="4": return
	gf.destroy()

def al1(event):#seçme olayı
	w=event.widget;g1.delete(0,END)
	g1.insert(END,w["text"][0])

def vazgec():#seçimden vazgeç
	global vzgdeg
	vzg.set(1);vzgdeg=vzg.get();gf.destroy()
	return vzgdeg
kp=Button(gf,text="Tamam",bg="red",command=al)
kp.place(x=370,y=10)
kp.bind("<Return>",al);
g1.bind("<Return>",al)#Return tuşuna basılınca
g1.bind("<KP_Enter>",al)#Enter tuşuna basılınca
sec0.bind("<Button-1>",al1);sec1.bind("<Button-1>",al1)
sec2.bind("<Button-1>",al1);sec3.bind("<Button-1>",al1)
vg=Button(gf,text="Vazgeç",bg="green",command=vazgec)
vg.place(x=370,y=50)
gf.wait_window(gf)#giriş formu kapatılana kadar bekle
if vzgdeg==1: sys.exit()
#**************************** karar penceresi bitti ***************************
pencere=Tk()
pencere.title(pb)
pencere.geometry("1060x660+290+60")
pencere.update_idletasks()#;print(pencere.winfo_height())
araclar=Toplevel(name="araclar",takefocus=False)
araclar.geometry("275x660+5+60")#;araclar.overrideredirect(True)
araclar.title("Araçlar")
f=Frame(araclar,width=250,height=570,bg="darkblue")#araçlar penceresine
f.place(x=1,y=128)
pencere.update()
adres=Entry(bg="darkgreen",fg="yellow");adres.place(x=5,rely=0.96,width=800)
#fare koordinatları
farex=Label(font="Ubuntu 10 bold",bg="darkgreen",fg="yellow");farex.place(x=805,rely=0.96,width=35)
farey=Label(font="Ubuntu 10 bold",bg="darkgreen",fg="yellow");farey.place(x=843,rely=0.96,width=35)
#kopyalama koordinatları
kopx=Label(font="Ubuntu 10 bold",text="x=",fg="red");kopx.place(x=880,rely=0.96,width=50)
kopy=Label(font="Ubuntu 10 bold",text="y=",fg="red");kopy.place(x=940,rely=0.96,width=50)
kopetk=Label(font="Ubuntu 10 bold",text="kopyalama koordinatları",fg="red",anchor="w")
kopetk.place(x=880,rely=0.93,width=165)


#*************************************************************************

#**************************** fonksiyonlar ***********************

def bağla(n):#bind lar için--liste olarak
	if n[0].winfo_class()=="Toplevel":#birisi neyse diğerleri de odur. Pencereler için
		for i in n:
			i.bind("<Motion>",farehesap);i.bind("<Control-Button-3>",secimiptal)
			i.bind("<Key>",tushareket);i.bind("<Alt-Enter>",faresec);i.bind("<Button-1>",adal)
			i.bind("<Configure>",geoyaz);i.bind("<Key>",tushareket);i.bind("<Alt-Enter>",faresec)
			i.bind("<Control-c>",kopyala);i.bind("<Control-v>",kopyala)
			i.bind("<ButtonRelease-1>",farehesap)
	else:#diğer araçlar için
		for i in n:
			i.bind("<Button-1>",adal);i.bind("<Button-1>",teksec);i.bind("<Control-Button-1>",sec)
			i.bind("<Control-Button-3>",secimiptal);i.bind("<B1-Motion>",yerdeg)
			i.bind("<Shift-B1-Motion>",enboy);i.bind("<Shift-Button-1>",sec)
			i.bind("<Shift-B1-Motion>",harkop);i.bind("<Shift-ButtonRelease-1>",kopya2)
			i.bind("<Key>",tushareket)

def topozyaz(event=None):#Toplevel araç özelliklerini yaz
	#pencere için geometri yerine width,height,rootx ve rooty de kullanılabilir.
	global sonbas,secilen,secis,sabit,araçliste
	for a in sonbas.winfo_children():#seçim işaretlerini kaldır
		if a.winfo_class()=="Frame" and a.winfo_name().startswith("_iss"):a.destroy()
	for a in secilen:
		i=araçliste.index(a)
		a["cursor"]=kursorlar[i]
	secilen=[];secis=[]
	spnen.delete(0,END);spnyuk.delete(0,END);spnx.delete(0,END);spny.delete(0,END)
	spnen["state"]=DISABLED;spnyuk["state"]=DISABLED
	spnx["state"]=DISABLED;spny["state"]=DISABLED
	snf=sonbas.__class__.__name__
	sonbas.update_idletasks();ad=sonbas.winfo_name()
	ky=sonbas.keys();y=5;vy=list(map(lambda x:sonbas[x],ky))
	for n in f.place_slaves():
		n.place_forget()
	geo=sonbas.wm_geometry();baslk=sonbas.title();pboy=",".join(map(str,sonbas.resizable()))
	simge="hourglass";ovr=sonbas.overrideredirect()
	if ovr==None:ovr="0"
	#verileri yazdır
	#önce sınıf, isim,başlık,geometri,resizable,override,simge...
	ozd["text"]="Araç özellikleri--"+snf
	etiket=["isim","başlık","geometri","resizable","overrideredirect","window icon"]
	deger=[ad,baslk,geo,pboy,ovr,simge]#overrideredirect,icon,state,max-min size,resizable
	di1=dict(zip(etiket,deger));di2=dict(zip(ky,vy));di1.update(di2)
	etksr=["isim","başlık","geometri","resizable","overrideredirect","window icon","bd","relief","cursor","bg","background","highlightbackground","highlightcolor","highlightthickness","padx","pady","takefocus"]
	for a in etksr:
		k=Label(f,text=a);k.place(x=2,y=y,height=20)
		dv=di1[a]
		if a=="window icon":dv=sonbas.wm_iconbitmap()
		if a in sabit:
			liste=sabit[a].split(",");liste=[x.replace("-",",") for x in liste]
			om=Combobox(f,values=liste,justify="center");om.place(x=160,y=y,height=20,width=80)
			if dv=="":
				om.set(liste[0])
			else:om.set(dv)
			om.bind("<<ComboboxSelected>>",yaz);om.bind("<Button-1>",srnoal)
		else:
			v=Entry(f,bg="lightblue",relief=FLAT,justify=CENTER,name=a)
			v.place(x=160,y=y,height=20,width=80)
			if a=="geometri":v.place_configure(x=90,width=150)
			if a in ["bg","background","highlightbackground","highlightcolor"]:
				wcktooltips.register(v,"renk düzenlemek için Ctrl+sol tık.")
				v.bind("<Control-Button-1>",renk)
			if a=="isim":
				wcktooltips.register(v,"form adı değiştirilebilir, programdaki form adlarını da değiştiriniz.")
			v.insert(END,di1[a]);v.bind("<FocusOut>",yaz);v.bind("<Button-1>",srnoal)
		y+=25

	ksay=(len(ky)+2)*20
	vs["to"]=ksay#kaydırma çubuğunu liste miktarına göre ayarla
	sonbas.update()
	sonbas.bind("<Button-1>",adal);sonbas.bind("<Configure>",geoyaz)

	return "break"

def srnoal(event):#basılan option button sıra no.
	global wad
	wad=event.widget

"""
Normalde araç isimleri, araç oluşturulduktan sonra çalışma zamanında değiştirilemez.
Biz daha değişik bir yöntem deneyeceğiz.
Önce araç özelliklerini alacağız. Sonra aracı yok edeceğiz.
Daha sonra, değiştirilen isimle, kayıtlı özellikleri göstererek yeniden oluşturacağız.
"""
def isimdeg(c):# pencere araçlarının isimlerini değiştir.
	global sonbas,secilen,ipu,resimyol,sayliste
	cl=sonbas.winfo_class();eskiad=sonbas.winfo_name();yeniad=c
	if cl=="Toplevel":
		kayıt.formkayıt(adres.get(),eskiad,yeniad)
		devam()
		return
	if c in sayliste:
		if c==sonbas.winfo_name():#aynı ad yazıldıysa
			f.place_slaves()[-2].delete(0,END)
			f.place_slaves()[-2].insert(END,c)
			return
		else:
			yz="""Bu isimde bir araç zaten var.\nLütfen başka bir isim seçin."""
			tkinter.messagebox.showwarning("Dikkat!",yz)
			f.place_slaves()[-2].delete(0,END)
			f.place_slaves()[-2].insert(END,sonbas.winfo_name())
			return "break"
	ipc="";tabsıra=""
	if len(secilen)==0:
		tkinter.messagebox.showwarning("Hiçbir aracı seçmediniz!","Lütfen önce bir araç seçin.\nHer seferde sadece bir aracın\nismi değiştirilebilir.")
		return "break"
	ead=sonbas.winfo_name()#aracın eski adı
	for ts in range(arlb.size()):
		tbs=arlb.get(ts)
		if ead in tbs:tabsıra=tbs.split("--")[1]
	el=f.place_slaves();el.reverse()#baştan alalım
	uel=len(el);ediz=[];ddiz=[]
	haric=[u"başlık",u"geometri",u"ipucu"]#["image","height","width","bitmap"]
	for a in range(2,uel,2):
		et=el[a][u"text"]#etiket metni---"key" ler.
		if et in haric: continue#keylerde ipucu yok, onun için hariç
		se=sonbas[et]
		ev=se
		if ev!="" and ev!="0":#sıfır olanlarla şişirmeyelim.
			ediz.append(et);ddiz.append(ev)#etiket metinleri(key ler) ve değerleri listelere at
	ayar=dict(zip(ediz,ddiz))#bu iki listeden ayarlar sözlüğü oluştur. Yani {*options}
	cw=sonbas.__class__.__name__ #yaratılmak istenen aracın sınıf adı
	#dict[new_key] = dict.pop(old_key)>>>ipucu sözlüğünde eski key yenisiyle değiştirilecek
	dp=sonbas.place_info();lst=("",)
	wn=sonbas.nametowidget(sonbas.winfo_parent())#aracın formunun adını al
	ic=dp["in"];cdx=dp["x"];cdy=dp["y"];cdw=dp["width"];cdh=dp["height"]#konum ve boyut bilgilerini al
	if ead in ipu:ipc=ipu[ead]
	sil()#eskisini uçur
	no=ar2[textliste.index(cw)]#şimdi yeni adla yenisini oluştur.
	if cw=="OptionMenu":
		yw=no(ic,None,*lst,name=c)#c=yeni ad
	else:
		yw=no(ic,name=c)#c=yeni ad
		yw.update()
	h=["container","class","visual","colormap"]
	for a in ayar.keys():
		if a in h:continue
		yw[a]=ayar[a]
	yw.place(x=cdx,y=cdy,width=cdw,height=cdh);sonbas=yw
	if c not in ipu:ipu[c]=ipc#ipu[c]=ipu.pop(ipc)#ipucu sözlüğündeki eski adı
	# yenisiyle değiştir
	if ead in resimyol:
		ri=resimyol.index(ead);resimyol[ri]=c;yw["image"]=resimyol[ri+1]#image yolunu ayarla
	bağla([sonbas])
	arlb.insert(END,sonbas.winfo_name()+"--"+str(tabsıra))
	seksra["values"]=list(range(arlb.size()))
	listeal()
	return "break"

def topyaz(ev):#toplevel aracının özelliklerini değiştirmek için
	global sonbas,kaydedildi
	kaydedildi=False;araclar.update()
	w=ev.widget;cw=w.winfo_class();fp=f.place_slaves()
	if cw=="Entry" or cw=="TCombobox":
		fst=fp[fp.index(w)+1]
		c=fp[fp.index(w)].get()
		ft=fst["text"]
		if ft=="isim":
			isimdeg(c);return
		if ft=="başlık":
			sonbas.title(c);return
		if ft=="geometri":
			sonbas.geometry(c);return
		if ft=="overrideredirect":
			sonbas.update_idletasks();c=int(c);sonbas.overrideredirect(c)
			sonbas.withdraw();sonbas.deiconify();return
		if ft=="resizable":
			sonbas.update_idletasks();sonbas.resizable(int(c[0]),int(c[2]))
			sonbas.withdraw();sonbas.deiconify();return
		if ft=="window icon":
			sonbas.wm_iconbitmap(c);sonbas.update();return
		else:
			sonbas[ft]=c
	if cw=="Menu":
		s=w.index("active")
		c=w.entrycget(s,"label")#çok güzel oldu
		fst=fp[fp.index(wad)+1]#etiketi bul
		ft=fst["text"]
		sonbas[ft]=c
	sonbas.update();sonbas.update_idletasks()

def yaz(event):#aracın değişen özelliğini yaz-böyle olmaz!!!
	global sonbas,wad,ipu,kaydedildi,resimyol,secilen,secis,araçliste,kursorlar
	sw=sonbas.__class__.__name__
	if sw=="Toplevel":topyaz(event);return
	kaydedildi=False
	tldiz=[];fp=f.place_slaves()
	for w in secilen:
		sonbas=w
		sw=sonbas.__class__.__name__
		for a in range(1,len(fp)):
			e=fp[a];tldiz.append(e["text"])#etiketler listesi oluştur
		w=event.widget;cw=w.__class__.__name__#winfo_class()
		if cw=="Entry" or cw=="Combobox":
			fst=fp[fp.index(w)+1];c=fp[fp.index(w)].get();ft=fst["text"]
			if ft=="isim":
				isimdeg(c);return
		if cw=="Menu":
			s=w.index("active")
			c=w.entrycget(s,"label")#çok güzel oldu
			fst=fp[fp.index(wad)+1]#etiketi bul
			ft=fst["text"]
		if sw=="Spinbox":
			if ft=="from" or ft=="to" or ft=="increment": c=float(c)
		if ft=="ipucu":#dikkat! isim değişirse?
			ipu[sonbas.winfo_name()]=c
			sonbas.update();return "break"
		if ft=="image":
			if c=="":
				resad=sonbas.winfo_name()
				if resad not in resimyol:return
				adno=resimyol.index(resad)
				del resimyol[adno:adno+2]
				sonbas[ft]=""
				return "break"
			return "break"
		if ft=="values":
			if c!="":
				c1=c.split(",")
				sonbas[ft]=c1
				return "break"
			return
		if ft=="orient":
			sonbas[ft]=c
			en,yuk=int(sonbas.place_info()["height"]),int(sonbas.place_info()["width"])
			sonbas.place_configure(width=en,height=yuk)
			secis[0].place_configure(width=en+10,height=yuk+10)
		if ft=="cursor":
			i=araçliste.index(sonbas)
			kursorlar[i]=c
		sonbas[ft]=c#değişikliği araca uygula
		if sonbas["takefocus"]=="0":
			diz=list(arlb.get(0,END));diz1=list(diz)
			for a in diz:
				n=a.split("--")[0];i=diz.index(a)
				if n==sonbas.winfo_name():
					del diz1[i];diz1.append(n+"-- yok")
			arlb.delete(0,END)
			for a in diz1:arlb.insert(END,a)
			seksra["state"]=DISABLED;return
		if sonbas["takefocus"]=="1":
			diz=list(arlb.get(0,END));diz1=list(diz)
			syok=str(arlb.get(0,END)).count("yok")
			for a in diz:
				n=a.split("--")[0];i=diz.index(a)
				if n==sonbas.winfo_name():
					del diz1[i];diz1.append(n+"--"+str(arlb.size()-syok))
			arlb.delete(0,END)
			for a in diz1:arlb.insert(END,a)
			seksra["state"]=NORMAL
		if ft=="bd":
			et=fp[tldiz.index("borderwidth")]#ilgili entry yi bul
			et.delete(0,END);et.insert(END,c)
		elif ft=="borderwidth":
			et=fp[tldiz.index("bd")]#ilgili entry yi bul
			et.delete(0,END);et.insert(END,c)
		sonbas.update()
	return "break"

def ozyaz(*args):#araç özelliklerini yaz
	global sonbas,ipu,resimyol,secilen,araçliste
	ismlst=[]
	try:
		for i in araçliste:
			ismlst.append(i.winfo_name())
		# ismlst = [x.winfo_name() for x in araçliste if "_iss" not in x.winfo_name()]
	except:
		pass

	try:
		snf=sonbas.__class__.__name__;wad=sonbas.winfo_name()
	except:
		sonbas_ad=sonbas.split("#")[-1]#menü hatalarını önle!!
		srn = ismlst.index(sonbas_ad)
		snf=araçliste[srn].winfo_class();wad=sonbas_ad;sonbas=araçliste[srn]
	# if snf=="Menu":menüyapım();return
	if wad[:4]=="_iss":return
	if snf=="Toplevel":
		seksra["state"]="disabled"
		sonbas.update();topozyaz();return
	if len(secilen)>1:return
	wn=sonbas.nametowidget(sonbas.winfo_parent())#formun adını al
	wpc=wn.winfo_class()
	wg=((wn.winfo_geometry()).split("+")[0]).split("x")#geometry ifadesini böl
	g=wg[0];y=wg[1]#formun genişlik ve yüksekliği
	spnx["to"]=int(g)-10;spny["to"]=int(y)-10#kaydırma sol ve üst sınırını ayarla
	ad=sonbas.winfo_name()#önce sınıf ve isim
	ozd["text"]="Araç özellikleri--"+snf
	ky=sonbas.keys();y=5
	if "textvariable" in ky:tv=sonbas["textvariable"]
	if snf=="Scrollbar":ky=sbky
	if snf=="Canvas":
		ky=list(sonbas.config().keys())
		ky.sort()
	for n in f.place_slaves():
		n.destroy()
	l=Label(f,text="isim");l.place(x=5,y=y)#önce isim yaz
	om=Entry(f,width=10,bd=1,bg="lightblue",relief="flat",justify="center",name="om"+str(y))
	om.place(x=160,y=y,height=20,width=80);om.insert(END,ad);om.bind("<FocusOut>",yaz)

#isim yazıldı, şimdi diğer özellikler
	y+=21;haric=["height","width","length"]
	for a in ky:
		if a in haric: continue
		l=Label(f,text=a);l.place(x=5,y=y);dv=sonbas[a]
		if a in sabit:
			liste=sabit[a].split(",")
			if snf=="Entry" and a=="state":liste[liste.index("active")]="readonly"
			om=Combobox(f,values=liste,justify="center");om.place(x=160,y=y,height=20,width=80);om.set(dv)
			if dv=="":om.set(liste[0])
			om.bind("<<ComboboxSelected>>",yaz)
		else:
			om=Entry(f,bd=1,bg="lightblue",relief="flat",justify="center",name="om"+str(y))
			om.place(x=160,y=y,height=20,width=80)
			om.insert(END,dv);om.bind("<FocusOut>",yaz)
			if om.get().startswith("#"): wcktooltips.register(om,"renk değiştirmek için CTRL+sol tık.")
			if a=="font": wcktooltips.register(om,"fontu değiştirmek için CTRL+sol tık.")
			if a=="values":
				wcktooltips.register(om,"değerleri virgülle ayırınız.")
				if sonbas["values"]!="":
					om.delete(0,END);om.insert(END,",".join(sonbas["values"]))
			if a=="image":#resim yolunu yazdır
				wcktooltips.register(om,"Resim yolunu almak için CTRL+sol tık.\nResmi silmek için yolu silip tab tuşuna basın.")
				if sonbas["image"]!="":
					if ad not in resimyol:break
					resad=resimyol[resimyol.index(ad)+1]
					om.delete(0,END);om.insert(END,resad)
		om.bind("<Control-Button-1>",renk)
		y+=21
	l=Label(f,text="ipucu");l.place(x=5,y=y)#ipucu metni için
	om=Entry(f,bg="lightblue",relief="flat",justify="center",name="ipucu")
	om.place(x=160,y=y,height=20,width=80)
	if ad in ipu:om.insert(END,ipu[ad])
	om.bind("<FocusOut>",yaz)
	if snf!="Menu":
		x=int(sonbas.place_info()["x"]);y=int(sonbas.place_info()["y"])# x ve y değerlerini yazdır
		gen=int(sonbas.place_info()["width"])
		yuk=int(sonbas.place_info()["height"])# genişlik ve yükseklik değerlerini yazdır
	if len(secilen)>1:
		wi=[];hi=[];xi=[];yi=[]
		seksra["state"]=DISABLED
		for n in secilen:
			wi.append(int(n.place_info()["width"]));hi.append(int(n.place_info()["height"]))
			xi.append(int(n.place_info()["x"]));yi.append(int(n.place_info()["y"]))
		if len(wi)==wi.count(wi[0]):#hepsinin genişliği aynı ise-all(x==myList[0] for x in myList),,,len(set(a)),,,,count=len(a) gibi yöntemler var
			spnen.delete(0,END);spnen.insert(END,wi[0])
		else:
			spnen.delete(0,END);spnen.insert(END,"")
		if len(hi)==hi.count(hi[0]):#hepsinin yüksekliği aynı ise
			spnyuk.delete(0,END);spnyuk.insert(END,hi[0])
		else:
			spnyuk.delete(0,END);spnyuk.insert(END,"")
		if len(xi)==xi.count(xi[0]):#hepsinin x değeri aynı ise
			spnx.delete(0,END);spnx.insert(END,xi[0])
		else:
			spnx.delete(0,END);spnx.insert(END,"")
		if len(yi)==yi.count(yi[0]):#hepsinin y değeri aynı ise
			spny.delete(0,END);spny.insert(END,yi[0])
		else:
			spny.delete(0,END);spny.insert(END,"")
	else:
		if snf!="Menu":
			spnen.delete(0,END);spnen.insert(END,gen);spnyuk.delete(0,END);spnyuk.insert(END,yuk)
			spnx.delete(0,END);spnx.insert(END,x);spny.delete(0,END);spny.insert(END,y)
			seksra["state"]="enabled"
	ksay=(len(ky)+2)*20
	vs["to"]=ksay#kaydırma çubuğunu liste miktarına göre ayarla
	return "break"


def fontsec(event):#araçların fontlarını ayarla
	global sonbas,kaydedildi,secilen
	fc = tkfontchooser.askfont()
	w=event.widget;wa=w.winfo_name()
	pencere.update()
	ft=" ".join([fc["family"].replace(" ",""),str(fc["size"]),fc["weight"]])
	# ft = pencere.clipboard_get()
	w.delete(0, END);w.insert(END, ft)
	if wa.startswith("om"):
	# if w.winfo_name()!= "fon":
		yaz(event)  # fontu yaz
		araclar.update()
		for a in secilen: a["font"] = ft
	w.update()
	pencere.update()

def renkseç(event):# menü çubuğu renkleri
	global sonbas,kaydedildi,secilen
	clo=askcolor(title="rengini seç")#RGB ve hex değeri döndürür, istediğini kullan
	r=clo[1]#....şeklinde, 0 yaparsan rgb şeklinde
	if r is None: return
	w=event.widget
	w.delete(0,END);w.insert(END,r);w.update()
	kaydedildi=False


def renk(event):#renk ve font aracıyla seçim. Fonta tıklanırsa fonta gider.
	global sonbas,kaydedildi,secilen,resimyol
	w=event.widget;wc=sonbas.winfo_class()
	#yardım için:help('tkColorChooser')
	fp=f.place_slaves();e=fp[fp.index(w)+1]["text"]#basılan girişin renk-font etiketini bul
	rk=sonbas[e];fc=""#entryde yazan
	if e=="font":fontsec(event);return #font yazarsa font değiştirmeye git
	if e=="image":
		clo=askopenfilename(title="resmi seç")
		rrr=ImageTk.PhotoImage(file=clo)
		gr=fp[fp.index(w)];gr.delete(0,END);gr.insert(END,clo)
		for s in secilen:
			s.image=rrr
			s.configure(image=rrr)
		resimyol.append(sonbas.winfo_name());resimyol.append(clo)
		return
	if str(rk).startswith("#")==False: return
	clo=askcolor(rk,title=e+" rengini seç")#RGB ve hex değeri döndürür, istediğini kullan
	r=clo[1]#....şeklinde, 0 yaparsan rgb şeklinde
	if r is None: return
	w.delete(0,END);w.insert(END,r)
	kaydedildi=False
	if secilen==[] and wc=="Toplevel":secilen.append(sonbas)
	for isimler in secilen:
		if e=="background" or e=="bg":
			isimler["background"]=r;isimler["bg"]=r;ozyaz()
		if e=="foreground" or e=="fg":
			isimler["foreground"]=r;isimler["fg"]=r;ozyaz()
		isimler.update()
	yaz(event)
	for p in pencere.winfo_children():p.lift()
	fp[fp.index(w)-2].focus_force()

def adal(event):#araç adını al
	global sonbas,secilen
	w=event.widget;lu=len(secilen)
	sonbas=w
	snf=sonbas.__class__.__name__
	if snf=="Toplevel" or snf=="PanedWindow":
		w.lift();sonbas.focus();seksra["state"]=DISABLED;ozyaz();return
	ozyaz()
	n=sonbas.winfo_name()
	arlbdiz=arlb.get(0,END)
	if snf!="str":
		if w["takefocus"]==0 or lu>1 :
			seksra["state"]=DISABLED;return
		else:
			seksra["state"]=NORMAL
	syok=str(arlb.get(0,END)).count("yok")
	seksra["values"]=list(range(arlb.size()))
	# seksra["values"]=list(range(arlb.size()-syok))#print(arlb.size())
	for i in arlbdiz:
		si=i.split("--")[1];sa=i.split("--")[0]
		if "yok" not in i and n==sa:
			seksra.current(si)
			break
	return "break"


def kurdeg(event):# seçildiğinde boyut ve hareket imleçleri
	global secilen,secis
	w=event.widget
	en1=int(w.place_info()["width"])/5;en2=en1*4
	boy1=int(w.place_info()["height"])/5;boy2=boy1*4
	cx=event.x;cy=event.y
	for a in secilen:a["cursor"]="hand2"
	if cx<en1 and cy>boy1 and cy<boy2:
		w["cursor"]="left_side"#sol kenar
	elif cx>en2 and cy>boy1 and cy<boy2:
		w["cursor"]="right_side"#sağ kenar
	elif cx>en1 and cx<en2 and  cy>boy2:
		w["cursor"]="bottom_side"#alt kenar
	elif cx>en1 and cx<en2 and cy<boy1:
		w["cursor"]="top_side"#üst kenar
	elif cx<en1 and cy<boy1:#sol üst
		w["cursor"]="top_left_corner"
	elif cx<en1 and cy>boy2:#sol alt
		w["cursor"]="bottom_left_corner"
	elif cx>en2 and cy<boy1:#sağ üst
		w["cursor"]="top_right_corner"
	elif cx>en2 and cy>boy2:#sağ alt
		w["cursor"]="bottom_right_corner"
	else:
		w["cursor"]="hand2"

def teksec(event):# tek aracın seçimi
	global secilen, sonbas,secis,araçliste#seçilenler ve seçim işaretleri
	wd = event.widget;#print(pencere.xview())
	wad=event.widget.winfo_name();wn=event.widget.winfo_class()
	if wad=="arlb":
		w=sonbas
	else:
		w=event.widget
	if wn!="Panedwindow":
		if w["takefocus"]==0:
			seksra["state"]=DISABLED
		else:
			seksra["state"]=NORMAL
	for s in secilen:
		i=araçliste.index(s)
		s["cursor"]=kursorlar[i]
	wad=w.winfo_name();secilen=[];secis=[]
	spnen["state"]=NORMAL;spnyuk["state"]=NORMAL
	spnx["state"]=NORMAL;spny["state"]=NORMAL
	if wad[:4]=="_iss":return
	secilen.append(w);w.lift()
	i=len(secilen)-1
	wn=w.nametowidget(w.winfo_parent())#aracın bulunduğu formun adını al
	if wn.winfo_class()=="Frame":
		ws=wn.winfo_parent();wn=w._nametowidget(ws)
	for a in wn.winfo_children():#varsa diğer seçim işaretlerini kaldır
		if a.winfo_class()=="Frame" and a.winfo_name().startswith("_iss"):a.destroy()
	wi=int(w.place_info()["x"]);hi=int(w.place_info()["y"])
	wen=int(w.place_info()["width"]);wboy=int(w.place_info()["height"])
	wnrenk=wn["bg"]
	la=Frame(wn,bd=2,bg=wnrenk,highlightbackground="red",highlightthickness=2,name="_iss"+w.winfo_name())
	la.place(x=wi-5,y=hi-5,width=wen+10,height=wboy+10)
	la.bind("<Motion>",kurdeg);la.bind("<Shift-B1-Motion>",enboy)
	secis.append(la);secilen[0].lift();#secis[0].lower()

def topluozyaz(*args):#birden fazla aracın ortak değerlerini yaz ve değiştir
	# global sonbas
	# p=sonbas.winfo_parent()
	# wn=sonbas._nametowidget(p)#aracın bulunduğu formun adını al
	for n in f.place_slaves():n.destroy()#önce mevcutları sil
	ky=args[0];wod=args[1];y=5;x=5
	for w in ky:
		et=Label(f,text=w);et.place(x=x,y=y)
		om=Entry(f,width=10,bd=1,bg="lightblue",relief="flat",justify="center",name="om"+str(y))
		# om.place(x=160,y=y,height=20,width=80);om.bind("<FocusOut>",yaz)
		if w in sabit:
			liste=sabit[w].split(",")
			# if snf=="Entry" and a=="state":liste[liste.index("active")]="readonly"
			om=Combobox(f,values=liste,justify="center")#;om.place(x=160,y=y,height=20,width=80)
			# om.set(dv)
			# if dv=="":om.set(liste[0])
			# om.set(liste[0])
			om.bind("<<ComboboxSelected>>",yaz)
		else:
			om=Entry(f,width=10,bd=1,bg="lightblue",relief="flat",justify="center",name="om"+str(y))
		om.place(x=160,y=y,height=20,width=80);om.bind("<FocusOut>",yaz)
		if w in wod:
			om.insert(END,wod[w])
			if wod[w].startswith("#"):om.bind("<Control-Button-1>",renk)
		y+=21
	uky=len(ky);ksay=(len(ky)+2)*20
	if uky==0:uky=1
	vs["sliderlength"]=2*vs["length"]/uky
	vs["to"]=ksay#kaydırma çubuğunu liste miktarına göre ayarla
	return "break"


def ortakyaz(ortakdeger,lortak,u):#ortak keylere göre ortak değerleri yaz
	odv=[];odd=[]
	for i in ortakdeger:
		sayaç=0
		for w in secilen:#aynı olan değerleri bul
			wi=str(w[i]);oi=ortakdeger[i]
			if wi == oi and wi!="":
				sayaç+=1
				if sayaç==u:
					odv.append (i);odd.append(str(w[i]))
			else:
				break
	od=dict(zip(odv,odd))#değerleri aynı olanların sözlüğü
	topluozyaz(lortak,od)#ortakdegerleri yazdır

def coksec(secilen):#birden fazla araç seçilirse özellikleri topluca değiştir.
	u=len(secilen);dl=[];snf=secilen[0].winfo_class()
	ortak=set(secilen[0].keys())
	if snf=="Scrollbar":ortak=set(sbky)
	for a in range(0,u):#aynı key lerden liste oluştur
		k=set(secilen[a].keys())
		snf=secilen[a].winfo_class()
		if snf=="Scrollbar": k=set(sbky)
		ortak=k & ortak;lortak=list(ortak)
	#genişlik ve yükseklik olmasın, onlar başka yerde
	if "width" in lortak:lortak.remove("width")
	if "height" in lortak:lortak.remove("height")
	lortak.sort()# key leri aynı olanlar
	for i in lortak:
		dl.append(str(secilen[0][i]))
	ortakdeger=dict(zip(lortak,dl))
	ortakyaz(ortakdeger,lortak,u)

#buraya kadar height,width,x ve y hariç diğer ortaklar bulundu
#şimdi de bunları bul ve ilgili yerlere yazdır
	ortakx=[];ortaky=[];ortakgen=[];ortakyuk=[]
	spnen.delete(0,END);spnyuk.delete(0,END);spnx.delete(0,END);spny.delete(0,END)
	for i in secilen:
		x=int(i.place_info()["x"]);y=int(i.place_info()["y"])# x ve y değerleri
		gen=int(i.place_info()["width"]);yuk=int(i.place_info()["height"])# genişlik ve yükseklik değerleri
		if x not in ortakx:ortakx.append(x)
		if y not in ortaky:ortaky.append(y)
		if gen not in ortakgen:ortakgen.append(gen)
		if yuk not in ortakyuk:ortakyuk.append(yuk)
	if len(ortakgen)==1:spnen.insert(END,ortakgen[0])
	if len(ortakyuk)==1:spnyuk.insert(END,ortakyuk[0])
	if len(ortakx)==1:spnx.insert(END,ortakx[0])
	if len(ortaky)==1:spny.insert(END,ortaky[0])

def faresec(event):# fareyi sürükleyerek çoklu seçim yap. Alt-Enter
	global secilen, sonbas,secis#seçilenler ve seçim işaretleri
	w=event.widget;sonbas=w;wsnf=w.winfo_class()
	ad=w.winfo_name()#;print(ad)
	if ad[:4]=="_iss":return
	if ad.isdigit()==True:return
	if w=="Toplevel":return
	if wsnf=="Toplevel":return
	if w not in secilen:#seçileni tekrar seçmemek için
		secilen.append(w)
		i=len(secilen)
		p=w.winfo_parent()
		wn=w._nametowidget(p)#aracın bulunduğu formun adını al
		awn=wn.winfo_class()
		if awn=="Frame":
			ws=wn.winfo_parent();wn=w._nametowidget(ws)
		wi=int(w.place_info()["x"]);hi=int(w.place_info()["y"])
		wen=int(w.place_info()["width"]);wboy=int(w.place_info()["height"])
		wnrenk=wn["bg"]
		la=Frame(wn,bd=2,bg=wnrenk,highlightbackground="red",highlightthickness=2,name="_iss"+w.winfo_name())
		la.place(x=wi-5,y=hi-5,width=wen+10,height=wboy+10)
		la.bind("<Motion>",kurdeg);la.bind("<Shift-B1-Motion>",enboy)
		secis.append(la);w.lift()
	if len(secilen)>1:coksec(secilen)
	if len(secilen)>1:
		seksra["state"]="disabled"
	else:
		seksra["state"]=NORMAL

def sec(event):#birden çok araç seç:control+B1
	global secilen, sonbas,secis#seçilenler ve seçim işaretleri
	w=event.widget;ws=sonbas.winfo_class();ad=w.winfo_name()
	if ad[:4]=="_iss":return
	if ws=="Toplevel":return
	try:
		w=event.widget
	except:
		w=sonbas
	if w not in secilen:#seçileni tekrar seçmemek için
		secilen.append(w)
		i=len(secilen)
		p=w.winfo_parent()
		wn=w._nametowidget(p)#aracın bulunduğu formun adını al
		if wn.winfo_class()=="Frame":
			ws=wn.winfo_parent();wn=w._nametowidget(ws)
		wi=int(w.place_info()["x"]);hi=int(w.place_info()["y"])
		wen=int(w.place_info()["width"]);wboy=int(w.place_info()["height"])
		wnrenk=wn["bg"]
		la=Frame(wn,bd=2,bg=wnrenk,highlightbackground="red",highlightthickness=2,name="_iss"+w.winfo_name())
		la.place(x=wi-5,y=hi-5,width=wen+10,height=wboy+10)
		la.bind("<Motion>",kurdeg);la.bind("<Shift-B1-Motion>",enboy)
		secis.append(la);la.lower();w.lift()
	if len(secilen)>1:
		seksra["state"]="disabled"
		# araçkursor()
		coksec(secilen)

def menüçubuğu(mf,pad,penad,yl):
	global kaydedildi
	mf.men_yap.update()
	mad=mf.pisim.get().strip();değerler=[]
	liste=[mf.misim,mf.mbg,mf.mfg,mf.teof,mf.fon,mf.etklerad]
	deglis=[x.get() for x in liste]
	etiketler=(deglis[5].strip()).split(",");pr=pad[penad.index(mad)]
	menubar=Menu(pr,name=deglis[0],bg=deglis[1],fg=deglis[2],tearoff=deglis[3],font=deglis[4])
	pr.config(menu=menubar)  # menü çubuğu görüntülensin
	değerler.append(pr);değerler.extend(deglis);etlis=["_eön","_ear","_eteo","_etfn"]
	print([x.winfo_name() for x in mf.men_yap.place_slaves() if x.winfo_name().startswith("_eön")])
	for w in etiketler:#ana etiketleri oluştur
		dl=[x.get() for x in mf.men_yap.place_slaves() if x.winfo_name().endswith(w) and x.winfo_class()=="Entry"];dl.reverse()
		m_1 = Menu(menubar, bg=dl[1],fg=dl[2],tearoff=int(dl[3]),font=dl[4],name=w)
		menubar.add_cascade(label=w, menu=m_1)
		pr.update()
	for e in etiketler:#önce menü penceresinden alt menü komutlarını oku!
		komut=mf.men_yap.__dict__["children"]["_"+e].get().split(",")#komut listesini al
		değerler.append(e);değerler.append(komut)
		for k in komut:
			kw=menubar.__dict__["children"][e]
			kw.add_command(label=k)
	pr.update()
	# with open (yl+"/"+"değeryaz","w") as ds:
	# 	u=len(değerler)#pencere ad,menü çubuğu adı,önalan,artalan,tearoff,font,ilk menü öğesi ve altındakiler.....
	# 	ds.write(değerler[0].winfo_name()+"\n"+"\n".join(değerler[1:6])+"\n")
	# 	# ds.write(önalan+"\n"+artalan+"\n")
	# 	for a in range(6,u,2):
	# 		da=değerler[a]
	# 		ds.write(değerler[a]+",");ttt=",".join(değerler[a+1])
	# 		ds.write(",".join(değerler[a+1]));ds.write("\n")
	# sonbas=menubar;sonbas.bind("<Button-1>",teksec)# menü de bu olmuyor!!
	kaydedildi=False


def dizi(mf,altet,event=None):
	global mef
	mf=mef;sraltet=0;l1=[]
	f=mf.men_yap.__dict__["children"];al=mf.etklerad.get();x=10;y=292
	if al!="":l1=mf.etklerad.get().split(",")
	if len(l1)>0:#liste boş değilse etiket ve girişleri oluştur.
		for a in l1:
			if a in f:f[a].destroy()
			eta="e_t"+str(l1.index(a))#öncekileri sil
			if eta in f:f[eta].destroy()
			et=Label(mf.men_yap,text=a,name=eta);et.place(x=x,y=y)
			el=Entry(mf.men_yap,name="_"+a);el.place(x=x+60,y=y,width=180,height=20)#ana girişler
			ear=Entry(mf.men_yap,name="_ear"+a);ear.place(x=x+257,y=y,width=84,height=20)
			eön=Entry(mf.men_yap,name="_eön"+a);eön.place(x=x+349,y=y,width=84,height=20)
			eteo=Entry(mf.men_yap,justify=CENTER,name="_eteo"+a);eteo.place(x=x+442,y=y,width=52,height=20)
			etfn=Entry(mf.men_yap,name="_etfn"+a);etfn.place(x=x+507,y=y,width=120,height=20)
			f["_ear"+a].bind("<Control-Button-1>",renkseç);f["_ear"+a].insert(END,"#1cd9d9")
			wcktooltips.register(f["_ear"+a],"Artalan için Ctrl+sol tık")
			f["_eön"+a].bind("<Control-Button-1>",renkseç);f["_eön"+a].insert(END,"#913011")
			wcktooltips.register(f["_eön"+a],"Önalan için Ctrl+sol tık")
			f["_etfn"+a].bind("<Control-Button-1>",fontsec);f["_etfn"+a].insert(END,"Arial 12 normal")
			wcktooltips.register(f["_etfn"+a],"Fontlar için Ctrl+sol tık")
			f["_eteo"+a].insert(END,"0")
			if len(altet)>0:
				el.insert(END,",".join(altet[sraltet]));sraltet+=1
			else:
				el.delete(0,END)#liste yoksa eskiyi sil
			y+=22

	if al=="":
		silinecek=[]
		for a in f:
			if a.startswith("_") or a.startswith("e_t"):
				silinecek.append(f[a])
		for i in silinecek:i.destroy()
	return f


def menüyapım():
	global sonbas,sayliste,kaydedildi,mef
	if sonbas.winfo_class()!="Toplevel":return
	pad=pencere.winfo_children();penad=[];altet=[];anaet=[]
	for p in pad:  # pencere adlarını bul
		if p.winfo_class() == "Toplevel":
			penad.append(p.winfo_name())
	symod=sys.modules.keys()
	if "menüyap" in symod:#önceden import edildiyse tekrar etme
		mef.men_yap.deiconify();pencere.update()
	else:
		from menüyap import menüyapform as mef
		sys.path.append(mef)
	yl=os.path.dirname(mef.__file__)#dosyanın yolu gerekiyor!
	c=sonbas.winfo_children();snf=[x.winfo_class() for x in c]
	mef.yap["command"] = lambda mf=mef:menüçubuğu(mf,pad,penad,yl)
	mef.bas["command"] = lambda mf=mef:dizi(mf,altet)
	mef.bas.bind("<Return>",lambda mf=mef :dizi(mf,altet,event=None))
	mef.ck["command"] = lambda :mef.men_yap.withdraw()
	mef.fon.bind("<Control-Button-1>",fontsec)
	mef.mbg.bind("<Control-Button-1>",renkseç)
	mef.mfg.bind("<Control-Button-1>",renkseç)
	mef.misim.delete(0,END)#;mef.misim.insert(END,sr.winfo_name()
	mef.pisim.delete(0,END);mef.pisim["values"]=penad
	mef.pisim.insert(0,sonbas.winfo_name())
	mef.mtür.delete(0,END);mef.mtür.insert(0,mef.mtür["values"][0])
	mef.fon.delete(0,END);mef.fon.insert(END,"Arial 10 normal")#varsayılan değerler
	mef.mbg.delete(0,END);mef.mbg.insert(END,"#1cd9d9")
	mef.mfg.delete(0,END);mef.mfg.insert(END,"#913011")
	mef.teof.delete(0,END);mef.teof.insert(END,"0")
	mef.etklerad.delete(0,END)
	mef.pisim.focus();pencere.update()
	f=dizi(mef,altet,event=None)
	# c=sonbas.winfo_children();snf=[x.winfo_class() for x in c]
	if "Menu" in snf:
		sr=c[snf.index("Menu")]
		mef.pisim.delete(0,END);mef.pisim.insert(0,sonbas.winfo_name())
		mef.mtür.delete(0,END);mef.mtür.insert(0,mef.mtür["values"][0])
		mef.misim.delete(0,END);mef.misim.insert(END,sr.winfo_name())
		mef.mbg.delete(0,END);mef.mbg.insert(END,sr["bg"])
		mef.mfg.delete(0,END);mef.mfg.insert(END,sr["fg"])
		mef.teof.delete(0,END);mef.teof.insert(END,sr["tearoff"])
		mef.fon.delete(0,END);mef.fon.insert(END,sr["font"])
		# print(sr.winfo_name(),sr["bg"],sr["fg"],sr["font"],sr["tearoff"])
		sno=sr.index("end")
		for a in range(0,sno+1):
			anaet.append(sr.entrycget(a,"label"))
		altöğe=sr.winfo_children()
		for i in altöğe:
			srn=i.index("end");altet.append([i.entrycget(ni,"label") for ni in range(i["tearoff"],srn+1)])
		mef.etklerad.delete(0,END);mef.etklerad.insert(END,",".join(anaet))
		f=dizi(mef,altet,event=None)
		# f["_eteodosya"].insert("end","0")
		for s,i in enumerate(altöğe,0):
			f["_ear"+anaet[s]].delete(0,END);f["_ear"+anaet[s]].insert(0,i["bg"])
			f["_eön"+anaet[s]].delete(0,END);f["_eön"+anaet[s]].insert(0,i["fg"])
			f["_eteo"+anaet[s]].delete(0,END);f["_eteo"+anaet[s]].insert(0,i["tearoff"])
			f["_etfn"+anaet[s]].delete(0,END);f["_etfn"+anaet[s]].insert(0,i["font"])

	mef.men_yap.update();pencere.update()



def formadal():
	import tkinter.simpledialog as sp
	ad=tkinter.simpledialog.askstring("Dikkat","Lütfen form adını giriniz")
	del sp;return ad
#**************************************************************************************

#ar2=(Button,Label,Text,Entry,Listbox,Checkbutton,Radiobutton,Frame,Canvas,Scale,Spinbox,
#PanedWindow,Toplevel,ScrolledText,Combobox,ScrolledList,Scrollbar,Menu,Message)

varsay=((80,30),(80,30),(100,150),(100,20),(100,150),(50,15),(50,15),(100,150),
				(100,150),(50,150),(80,20),(150,150),(150,150),(150,150),(80,20),
				(150,150),(15,100),(15,100),(80,30))#araçların varsayılan gen.ve yüksekliği

def yap(m):#araç oluşturma fonksiyonu--en önemli bölüm
	global sonbas,sayliste,kaydedildi
	sno=ar2.index(m)#12=Toplevel, 17=Menu
	if sno==17:menüyapım();return
	if sonbas=="" and sno!=12:
		tkinter.messagebox.showwarning("Uyarı!","Toplevel penceresi yok")
		return
	elif sonbas=="" and sno==12:
		sc="Toplevel";sonbas=fr
	else:
		sc=sonbas.winfo_class()
	if sc!="Toplevel":
		tkinter.messagebox.showwarning("Uyarı!","Araçlar sadece pencere üzerinde oluşturulabilir. Önce, araç oluşturacağınız pencereyi seçin")
		return
	arno1=[0,1,3,5,6,10,18];arno2=[2,4,7,8,13,14,15]
	en=varsay[sno][0];boy=varsay[sno][1]
	sayac=len(sayliste)+1
	isim1="form"+str(sayac);isim2="yeni"+str(sayac)
	while (isim1 and isim2) in sayliste:
		sayac+=1;isim1="form"+str(sayac);isim2="yeni"+str(sayac)
	if sno==12:#toplevel aracı
		ad=formadal()
		k=m(pencere,takefocus=True,bg="#90ee90",name=ad)
		k.geometry("150x150+500+220");k.title("yeni form")
		k.transient(pencere);sonbas=k;pencere.update();k.deiconify()
	elif sno==9 or sno==16:#scale ve scrollbar aracı:height yerine length var
		k=m(sonbas,bg="#90ee90",name="yeni"+str(sayac))
		k.place(x=5,y=5,width=en,height=boy)
	elif sno==11:#paned window
		k=m(sonbas,bg="#90ee90",showhandle=1,name="yeni"+str(sayac))
		k.place(x=5,y=5,width=en,height=boy)
	elif sno in arno2:#text aracı
		k=m(sonbas,background="#006400",takefocus=0,name="yeni"+str(sayac))
		k.place(x=5,y=5,width=en,height=boy)
	elif sno in arno1:
		k=m(sonbas,text="yeni",bg="#90ee90",textvariable="",takefocus=1,name="yeni"+str(sayac))
		k.place(x=5,y=5,width=en,height=boy)
		if sno==5 or sno==6:k["variable"]="vr"+str(sayac)
	sonbas=k;sayac+=1;sonbas.update()
	sonbas.bind("<Button-1>",adal);sonbas.bind("<Button-1>",teksec)
	snf=sonbas.__class__.__name__;ad=sonbas.winfo_name()
	# sonbas.bind("<Button-1>",adal);sonbas.bind("<Button-1>",teksec)
	bağla([sonbas])
	if snf!="Toplevel":
		syok=str(arlb.get(0,END)).count("yok")
		arlb.insert(END,ad+"--"+str(arlb.size()-syok))
		seksra["values"]=list(range(arlb.size()-syok))
	if snf=="Toplevel":
		bağla([sonbas])
	kaydedildi=False
	for p in pencere.winfo_children():
		if p.winfo_class()=="Toplevel":p.deiconify()
	# sayliste.append(k.winfo_name())#;print (sayliste)
	listeal();ozyaz()

#**********************
def enveboy(event=None):#en ve boy değiştir, yazılan değerlere göre
	global sonbas,secilen,secis,kaydedildi
	kaydedildi=False
	w=sonbas.winfo_class()
	wp=sonbas.winfo_parent();wn=sonbas._nametowidget(wp)
	if w=="Toplevel": return
	g=spnen.get();yk=spnyuk.get()
	if len(secilen)>1:#birden fazla araç seçilmiş ise
		if g!="":
			for a in secilen:
				i=secilen.index(a);g=int(g)
				a.place_configure(width=g);secis[i].place_configure(width=g+10)
		if yk!="":
			for a in secilen:
				i=secilen.index(a);yk=int(yk)
				a.place_configure(height=yk);secis[i].place_configure(height=yk+10)
	else:
		g=int(g);yk=int(yk)
		sonbas.place_configure(width=g,height=yk)
		secis[0].place_configure(width=g+10,height=yk+10)

def tushareket(event):#ok düğmeleriyle hareket
	global secilen,secis,kaydedildi
	if secilen==[]:return
	tuşlar=["Right","Left","Up","Down"]
	t=event.keysym
	# print (t,c)
	if t not in tuşlar:return
	kaydedildi=False
	sol,üst,sağ,alt=enkucukxy()
	for w in secilen:
		wn=w.nametowidget(w.winfo_parent())#aracın bulunduğu formun adını al
		awn=wn.winfo_class()
		if awn=="Frame":
			ws=wn.winfo_parent();wn=w._nametowidget(ws)
		gen,yuk=wn.winfo_width(),wn.winfo_height()
		s=secis[secilen.index(w)]
		if w.winfo_class()=="Entry": wn.focus_force()
		if t=="Right":
			if sağ>gen-10:return
			w.place_configure(x=int(w.place_info()["x"])+1)
			s.place_configure(x=int(s.place_info()["x"])+1)

		if t=="Left":
			if sol<10: return
			w.place_configure(x=int(w.place_info()["x"])-1)
			s.place_configure(x=int(s.place_info()["x"])-1)

		if t=="Up":
			if üst<10:return
			w.place_configure(y=int(w.place_info()["y"])-1)
			s.place_configure(y=int(s.place_info()["y"])-1)

		if t=="Down":
			if alt>yuk-10:return
			w.place_configure(y=int(w.place_info()["y"])+1)
			s.place_configure(y=int(s.place_info()["y"])+1)

		ax,by=int(w.place_info()["x"]),int(w.place_info()["y"])
		spnx.delete(0,END);spnx.insert(END,ax)
		spny.delete(0,END);spny.insert(END,by)

def farehesap(event):#koordinatları etiketlere yazdır, hareket için de gerekli.
	global secis,farklarx,farklary
	w=event.widget;wc=w.winfo_class();ws=event.num
	fx,fy=event.x_root,event.y_root
	farklarx.append(fx);farklary.append(fy)
	farklarx[:-2]=[];farklary[:-2]=[]
	if wc!="Toplevel":
		ex=event.x+int(w.place_info()["x"]);ey=event.y+int(w.place_info()["y"])
	else:ex=event.x;ey=event.y
	farex["text"]=ex;farey["text"]=ey
	if ws==1 and wc=="Toplevel":
		kopx["text"]="x="+str(event.x);kopy["text"]="y="+str(event.y)
	# print(event.num)
	return farklarx,farklary

def yerdeg(event):#fare kullanarak yer değiştir--B1-Motion
	global secilen,secis,kaydedildi,farklarx,farklary
	kaydedildi=False
	# print(event.keycode)
	curw=event.widget["cursor"]
	farkx=farklarx[-1]-farklarx[0];farky=farklary[-1]-farklary[0]
	for w in secis:
		i=secis.index(w);ws=secilen[i]
		wx=int(w.place_info()["x"]);wy=int(w.place_info()["y"])
		w.place_configure(x=wx+farkx,y=wy+farky)
		wxs=int(ws.place_info()["x"])
		wys=int(ws.place_info()["y"])
		secilen[i].place_configure(x=wxs+farkx,y=wys+farky)
		ax,by=int(ws.place_info()["x"]),int(ws.place_info()["y"])
		spnx.delete(0,END);spnx.insert(END,ax)
		spny.delete(0,END);spny.insert(END,by)


def enboy(event):#fare kullanarak boyut değiştir--Shift-B1-Motion
	global secilen,secis,farklarx,farklary,kaydedildi
	kaydedildi=False
	ew=event.widget
	curws=["right_side","left_side","bottom_side","top_side","top_right_corner","bottom_right_corner"]
	curws.extend(["top_left_corner","bottom_left_corner"])
	curw=ew["cursor"]
	if curw not in curws:
		harkop();return
	farkx=farklarx[-1]-farklarx[0];farky=farklary[-1]-farklary[0]
	for w in secis:
		en=int(w.place_info()["width"]);boy=int(w.place_info()["height"]);i=secis.index(w)
		wx=int(w.place_info()["x"]);wy=int(w.place_info()["y"])
		if curw=="right_side":#sağa genişlet--enini arttır
			w.place_configure(width=en+farkx);secilen[i].place_configure(width=en+farkx-10)
			continue
		elif curw=="left_side":#sola doğru genişlet
			w.place_configure(x=wx+farkx,width=en-farkx)
			secilen[i].place_configure(x=wx+farkx+5,width=en-farkx-10);continue
		elif curw=="bottom_side":#aşağıya genişlet--yükseklik arttır
			w.place_configure(height=boy+farky)
			secilen[i].place_configure(height=boy+farky-10);continue
		elif curw=="top_side":#yukarı doğru genişlet
			w.place_configure(y=wy+farky,height=boy-farky)
			secilen[i].place_configure(y=wy+farky+5,height=boy-farky-10);continue
		elif curw=="bottom_right_corner":#sağ aşağı köşeden genişlet
			w.place_configure(width=en+farkx,height=boy+farky)
			secilen[i].place_configure(width=en+farkx-10,height=boy+farky-10)
			continue
		elif curw=="top_right_corner":#sağ yukarı köşeden genişlet
			w.place_configure(width=en+farkx,height=boy-farky,y=wy+farky)
			secilen[i].place_configure(width=en+farkx-10,y=wy+farky+5,height=boy-farky-10)
			continue
		elif curw=="top_left_corner":#sol yukarı köşeden genişlet
			w.place_configure(width=en-farkx,height=boy-farky,x=wx+farkx,y=wy+farky)
			secilen[i].place_configure(x=wx+farkx+5,width=en-farkx-10,y=wy+farky+5,height=boy-farky-10)
			continue
		elif curw=="bottom_left_corner":#sol aşağı köşeden genişlet
			w.place_configure(width=en-farkx,height=boy+farky,x=wx+farkx)
			secilen[i].place_configure(x=wx+farkx+5,width=en-farkx-10,height=boy+farky-10)
			continue

	for w in secilen:
		gen,yuk=int(w.place_info()["width"]),int(w.place_info()["height"])
		wx,wy=int(w.place_info()["x"]),int(w.place_info()["y"])
		spnen.delete(0,END);spnen.insert(END,gen);spnyuk.delete(0,END);spnyuk.insert(END,yuk)
		spnx.delete(0,END);spnx.insert(END,wx)
		spny.delete(0,END);spny.insert(END,wy)

#****************
def har(n):#kaydırma çubuğu hareket
	d=f.place_slaves();d.reverse();y=0-int(n)+5
	ud=len(d)
	for a in range(0,ud,2):
		a1=d[a];a2=d[a+1]
		x1=a1.winfo_x();x2=a2.winfo_x()
		a1.place(x=x1,y=y);a2.place(x=x2,y=y)
		y+=25

def tekerlek(event):#fare tekerleğine göre araçlar penceresindeki scale sürgüsünü kaydır.
	d=int(vs.get())
	n=event.num
	if n==5: d+=30#yukarı dönüyorsa
	if n==4: d-=30#aşağı dönüyorsa
	vs.set(d)

def enkucukxy():#hizalamalar için en küçük/büyük x ve y değerleri
	global secilen
	xdiz,ydiz=[int(i.place_info()["x"]) for i in secilen],[int(i.place_info()["y"]) for i in secilen]
	gendiz=[int(secilen[i].place_info()["width"])+xdiz[i] for i in range(len(secilen))]
	yukdiz=[int(secilen[i].place_info()["height"])+ydiz[i] for i in range(len(secilen))]
	x1=min(xdiz);y1=min(ydiz)#en küçük sol ve üst değerleri
	x2=max(gendiz);y2=max(yukdiz)#en büyük sağ kenar ve alt kenar değerleri
	return x1,y1,x2,y2

def konumx(event=None):#yazarak konum ayarlama için
	global sonbas,kaydedildi,secilen,secis
	if sonbas.winfo_class()=="Toplevel":return
	x=spnx.get()
	if x=="":return "break"
	for a in secilen:
		ai=secilen.index(a)
		a.place_configure(x=x);secis[ai].place_configure(x=int(x)-5)
	kaydedildi=False

def konumy(event=None):#yazarak konum ayarlama için
	global sonbas,kaydedildi,secilen,secis
	if sonbas.winfo_class()=="Toplevel":return
	y=spny.get()
	if y=="":return "break"
	for a in secilen:
		ai=secilen.index(a)
		a.place_configure(y=y)
		secis[ai].place_configure(y=int(y)-5)
	kaydedildi=False

def dugmeebat(m):#araççubuğu düğmeleriyle ebat, yer değiştir ve hizala
	global sonbas,secilen,kaydedildi,secis
	kaydedildi=False
	n=sonbas.focus_lastfor()
	if n.winfo_class=="Entry": TK().focus()
	w=sonbas
	en=int(w.place_info()["width"]);yuk=int(w.place_info()["height"])
	sl=int(w.place_info()["x"]);yk=int(w.place_info()["y"])
	#dugmeisimliste=["en1","en2","boy1","boy2","us","alt","sol","sag"]---en-boy düğmeleri
	if m=="en1":
		w.place_configure(width=en-1)
	if m=="en2":
		w.place_configure(width=en+1)
	if m=="boy1":
		w.place_configure(height=yuk-1)
	if m=="boy2":
		w.place_configure(height=yuk+1)
	#hizalama rutinleri
	hiz=["us","alt","sol","sag"]
	if m in hiz:
		x1,y1,x2,y2=enkucukxy()
		if m=="us":
			for a in secilen: a.place_configure(y=y1)
			for a in secis:a.place_configure(y=y1-5)
			spny.delete(0,END);spny.insert(END,y1)
		if m=="sol":
			for a in secilen: a.place_configure(x=x1)
			for a in secis:a.place_configure(x=x1-5)
			spnx.delete(0,END);spnx.insert(END,x1)
		if m=="sag":
			sayaç=0
			for a in secilen:
				sl=int(a.place_info()["x"]);g=int(a.place_info()["width"])
				a.place_configure(x=sl+(x2-(sl+g)))
				secis[sayaç].place_configure(x=sl+(x2-(sl+g))-5)
				sayaç+=1
		if m=="alt":
			sayaç=0
			for a in secilen:
				yk=int(a.place_info()["y"]);g=int(a.place_info()["height"])
				a.place_configure(y=yk+(y2-(yk+g)))
				secis[sayaç].place_configure(y=yk+(y2-(yk+g))-5)
				sayaç+=1
	sonbas.update()
	n.focus()


def topsil():
	global sonbas
	kaydedildi=False;arçliste=[];silliste=[]
	ms="Bir pencereyi silmek üzeresiniz.\nPencere silinirse, üzerindeki tüm\n" \
	   "araçlar da silinecektir. Devam edecek misiniz?"
	cevap=tkinter.messagebox.askyesno("Dikkat!",ms)
	if cevap==False:return
	if cevap==True:
		p=sonbas.winfo_children()
		for a in p:silliste.append(a.winfo_name())
		for i in range(arlb.size()):
			n=arlb.get(str(i)).split("--")[0]
			if n in silliste:arlb.delete(i)
	sonbas.destroy()

def menüsil():
	global secilen,kaydedildi,sonbas
	kaydedildi=False
	tsnf=sonbas.winfo_class()
	if tsnf=="Toplevel":
		mad=sonbas.winfo_children()
		for a in mad:
			if a.winfo_class()=="Menu":
				a.destroy();break


def sil():#seçilen aracı sil
	global sonbas,ipu,secilen,secis,kaydedildi,pencere
	kaydedildi=False
	tsnf=sonbas.winfo_class()
	if tsnf=="Toplevel":topsil();return
	if len(secilen)==0:
		tkinter.messagebox.showwarning("Hiçbir aracı seçmediniz!","Silmek istediğiniz araç(lar)ı seçiniz")
		return "break"
	for w in secilen:
		wad=w.winfo_name()
		for i in range(arlb.size()):
			n=arlb.get(str(i))
			if wad in n: arlb.delete(i)
		if wad in ipu:del ipu[wad]
		p=w.winfo_parent()
		wn=w._nametowidget(p)#aracın bulunduğu formun adını al
		if wn.winfo_class()=="Frame":
			wn.destroy()
		else:
			w.destroy()
		secis[secilen.index(w)].destroy()
	syok=str(arlb.get(0,END)).count("yok")
	seksra["values"]=list(range(arlb.size()-syok))
	secilen=[];secis=[];listeal()

def farkkaydet():#dosyayı başka bir adla kaydet
	adres.delete(0,END)
	kaydet()

def kaydet(event=None):#olayın en babayiğit bölümü!!
	global kaydedildi,secis,sbky
	kayıt.kaydet(pencere,secis,adres,kaydedildi,arlb,resimyol,ipu,sbky)
	kaydedildi=kayıt.kaydedildi
	return"break"

def çalıştır():#programı çalıştır
	y=os.getcwd()
	ad=y.split("/")[-1]
	ad=ad+"prg.py"
	if os.path.exists(ad):
		os.system("python3 "+ad+" &")
	else:
		dy=[i for i in os.listdir(y) if "prg.py" in i][0]
		ad=y+"/"+dy
		os.system("python3 "+"'"+ad+"'"+" &")

def tasarla():#program kodlarını gör
	y=os.getcwd()
	ad=y.split("/")[-1]
	ad=ad+"prg.py"
	if os.path.exists(ad):
		os.system("gedit "+"'"+ad+"'")
	else:
		dy=[i for i in os.listdir(y) if "prg.py" in i][0]
		ad=y+"/"+dy
		os.system("gedit "+"'"+ad+"'")

def kodgir():#form kodlarını aç
	adr=adres.get()
	os.system("gedit "+"'"+adr+"'")
	ust.update_idletasks()
	pencere.focus()

def geoyaz(event):#pencere konum-boyutu değişince geometriyi değiştir
	global sonbas;snf=sonbas.winfo_class()
	w=event.widget
	if snf!="Toplevel":return
	n=f.place_slaves()
	if len(n)>0:
		n[28].delete(0,END);n[28].insert(END,sonbas.geometry())
	else:
		return

def ac():#varolan dosyayı aç
	global pencere,sonbas,anaprgyol,ipu,kaydedildi,resimyol
	fl=askopenfilename(title="Açacağınız dosyayı seçin")
	if fl=="":
		return
	else:
		kapat()
		adres.delete(0,END);adres.insert(END,fl)#dosya yolunu al ve yaz
		yl=fl.rsplit("/",1)[0];os.chdir(yl+"/");sys.path.append(yl);d=os.path.splitext(os.path.basename(fl))[0]
		if d in sys.modules:
			del (sys.modules[d])
		gel=importlib.import_module(d)
		ch=gel.pencere.winfo_children()
		for i in ch:#Toplevel'ın her biri
			bağla([i])
			for a in (i.winfo_children()):#Toplevel üzerindeki nesneler
				adet=len(a.winfo_children())#arlb.insert(END,a.winfo_name()+"--"+str(sy))
				if adet>0: a=a.winfo_children()[adet-1]
				bağla([a])
		pencere=gel.pencere;ipu=gel.ipuclar;resimyol=gel.resimyol
	try:
		for n in enumerate(gel.tabsr):
			arlb.insert(END,n[1].winfo_name()+"--"+str(n[0]))
	except:
		sy=0
		for a in (i.winfo_children()):#Toplevel üzerindeki nesneler
			arlb.insert(END,a.winfo_name()+"--"+str(sy))
			sy+=1
		seksra["values"]=list(range(arlb.size()))
	i.focus();sonbas=i;topozyaz()
	# sy=os.path.dirname(anaprgyol);sy=sy+"/"+"sonyol"
	ds=open(ana_dizin+"/sonyol","w")
	ds.write(fl);ds.close()#son dosyanın yolunu ana program dizinine yaz.
	listeal()
def kapatsor():#kapatırken kaydetmek istiyor musunuz?
	global kaydedildi
	if kaydedildi is True:kapat();return
	c=tkinter.messagebox.askyesno("Uyarı!","Mevcut dosya kapatılacak!\nÇalışmalarınızı kaydetmek istiyor musunuz?")
	if c==True:
		kaydet();kapat()
	else:
		kapat()

def kapat():
	global pencere,sonbas,resimyol
	n=pencere.winfo_children();formdiz=[];resimyol=[]
	haricler=[u"Araçlar",u"Araç Çubuğu",u"arayüz tasarımı"]
	for a in n:
		snf=a.winfo_class()
		if snf=="Entry" or snf=="Listbox" or snf=="Label" or snf=="Scale": continue
		i=a.title()
		if i not in haricler: formdiz.append(n[(n.index(a))])
	for a in formdiz:
		a.destroy()
	sonbas="";arlb.delete(0,END);adres.delete(0,END)

def ck():#programdan çıkış
	global kaydedildi
	if kaydedildi is True:pencere.quit();return "break"
	c=tkinter.messagebox.askyesnocancel("Uyarı!","Bazı değişiklikler yaptınız.\nProgramdan çıkmadan önce\nçalışmalarınızı kaydetmek\nistiyor musunuz?")
	if c==False:
		sys.exit()
	if c==True:
		kaydet();sys.exit();return
	if c is None: return

def harkop(event=None):#hareket ettirerek kopyalamak için
	fx,fy=konumfark(secis)
	for s,r in enumerate(secis):
		px=int(r.place_info()["x"]);py=int(r.place_info()["y"])
		# gen=int(r.place_info()["width"])/2;yük=int(r.place_info()["height"])/2
		# ex,ey=int(farex["text"])-gen,int(farey["text"])-yük
		ex,ey=int(farex["text"]),int(farey["text"])
		r.place_configure(x=ex+fx[s],y=ey+fy[s])

def kopya2(event=None):#seçilen aracın kopyalanması
	global sonbas,secilen,kaydedildi,resimyol
	kaydedildi=False;wn=sonbas.nametowidget(sonbas.winfo_parent());wn.update()#aracın formunun adını al
	if len(secilen)==0:
		tkinter.messagebox.showerror("Dikkat!!","Hiçbir araç seçmediniz.")
		return
	for s,n in enumerate(secilen):
		isim=n.winfo_name()+"kopya"+str(s);snf=n.__class__
		isimler=[x.winfo_name() for x in wn.winfo_children()];uis=len(isimler)+1
		if isim in isimler:isim=isim+str(uis)#isim değişikliğini garantiye al
		if n.winfo_name() in resimyol:
			resimyol.append(isim);resimyol.append(resimyol[resimyol.index(n.winfo_name())+1])
		en,boy=int(n.place_info()["width"]),int(n.place_info()["height"])
		x,y=int(secis[s].place_info()["x"])+5,int(secis[s].place_info()["y"])+5
		yy=snf(wn,name=isim);text=isim
		h=["container","class","visual","colormap","text"];sonbas=yy
		for key in n.configure():
			if key in h:continue
			yy.configure({key:n.cget(key)})
		yy.place(x=x,y=y,width=en,height=boy)
		bağla([sonbas])
		# sonbas.bind("<Button-1>",adal);sonbas.bind("<Control-Button-1>",sec)
		# sonbas.bind("<Button-1>",teksec);sonbas.bind("<B1-Motion>",yerdeg)
		# sonbas.bind("<Shift-Button-1>",sec);sonbas.bind("<Shift-B1-Motion>",harkop)
		# sonbas.bind("<Shift-ButtonRelease-1>",kopya2)
		syok=str(arlb.get(0,END)).count("yok")
		arlb.insert(END,isim+"--"+str(arlb.size()-syok));arlb.update()
		seksra["values"]=list(range(arlb.size()-syok));seksra.update()
		pencere.update();listeal();ozyaz()
	# for i in secis:i.unbind("<Shift-ButtonRelease-1>")

def konumfark(secarac):#kopyalamadan önce konum farklarını al
	u=len(secarac)
	xler=[int(i.place_info()["x"]) for i in secarac];yler=[int(i.place_info()["y"]) for i in secarac]
	xfark=[xler[i]-xler[0] for i in range(u)];yfark=[yler[i]-yler[0] for i in range(u)]
	return xfark,yfark

def kopyala(event=None):#seçilen aracın kopyalanması
	"""Dikkat! Araç kopyalanınca sadece isim değiştirilir. Diğer tüm özellikler, kopyalandığı nesneden aynen alınır.(ipucu-variable hariç)
	Kaynak araçtan yeni araca geçen bazı özellikleri değiştiriniz, aksi halde checkbutton gibi	araçların kullanılmasında aksaklık meydana gelir. Entry araçlarının -textvariable- değerlerini kontrol ediniz, aynı olmasın. """
	global sonbas,secilen,kaydedildi,w_ayar,resimyol
	sonbas.update();u=len(secilen);farkx=[0];farky=[0]
	kaydedildi=False;isimler=[];ko_t=ko["text"]
	if ko_t=="kopyala":
		kopx["text"]="x=";kopy["text"]="y="
		if u==0:
			tkinter.messagebox.showerror("Dikkat!!","Hiçbir araç seçmediniz.")
			return
		if u>1:farkx,farky=konumfark(secilen)
		for r,n in enumerate(secilen):
			wn=n.nametowidget(n.winfo_parent())#aracın formunun adını al
			wn.update()
			wc=wn.winfo_children();uwc=len(wc)+1
			snf=n.__class__;sn=ar2.index(snf);isim=n.winfo_name()+str(uwc)#"kopya"
			for ii in wc:isimler.append(ii.winfo_name())
			# if isim in isimler:isim=isim+str(uwc)#"kopya"#isim değişikliğini garantiye al
			if n.winfo_name() in resimyol:
				resimyol.append(isim);resimyol.append(resimyol[resimyol.index(n.winfo_name())+1])
			kk=n.keys();k=[];v=[]
			for i in kk:
				h=["container","class","visual","colormap"]
				if i in h:continue
				d=n[i];k.append(i);v.append(d)
			ayar=dict(zip(k,v));ng=int(n.place_info()["width"]);ny=int(n.place_info()["height"])
			wc=wn.winfo_class()
			if wc=="Frame":
				ws=wn.winfo_parent();wn=n._nametowidget(ws)
			wn.update();x=int(wn.winfo_width())-10-ng;y=int(wn.winfo_height())-100
			w_ayar.append(ayar)
			yz=str(sn)+"--"+isim+"--"+str(ng)+"--"+str(ny)+"--"+str(farkx[r])+"--"+str(farky[r])
			pencere.clipboard_append(yz+":")
		ko["text"]="yapıştır";return
	if ko_t=="yapıştır":
		wn=sonbas
		if wn.winfo_class()!="Toplevel":
			tkinter.messagebox.showerror("Dikkat!! Form seçmediniz.","Yapıştırmadan önce bir form seçin")
			return
		ko["text"]="kopyala"
		oku=pencere.clipboard_get().split(":")#kopyalanacak araç kadar liste elemanı
		del oku[-1]#boşluğu sil
		for s,o in enumerate(oku):
			ok=o.split("--")
			sn,isim,ng,ny,fx,fy=int(ok[0]),ok[1],int(ok[2]),int(ok[3]),int(ok[4]),int(ok[5])
			ayar=w_ayar[s]
			yy=ar2[sn](wn,name=isim)#aracı oluştur
			for a,b in ayar.items():#variable değiştirilebilir mi?Evet.
				if a=="variable":
					yy[a]=str(b)+"kopya"
				else:
					yy[a]=b
				if a=="image" and b!="":
					resad=resimyol[resimyol.index(isim)+1]
					rrr=ImageTk.PhotoImage(file=resad)
					yy.image=rrr
			x=farex["text"];y=farey["text"]
			if kopx["text"]=="x=":
				x=farex["text"];y=farey["text"]
			else:
				x,y=int(kopx["text"].split("=")[-1]),int(kopy["text"].split("=")[-1])
			yy.place(x=x+fx,y=y+fy,width=ng,height=ny)#çoklu seçimde koordinat farklarını dikkate al!!
			sonbas=yy;yy.focus()
			bağla([sonbas])
			# sonbas.bind("<Button-1>",adal);sonbas.bind("<Control-Button-1>",sec)
			# sonbas.bind("<Button-1>",teksec);sonbas.bind("<B1-Motion>",yerdeg)
			# sonbas.bind("<Shift-Button-1>",sec);sonbas.bind("<Shift-B1-Motion>",harkop)
			# sonbas.bind("<Shift-ButtonRelease-1>",kopya2)
			syok=str(arlb.get(0,END)).count("yok")
			arlb.insert(END,isim+"--"+str(arlb.size()-syok));arlb.update()
			seksra["values"]=list(range(arlb.size()-syok));seksra.update()
	pencere.update();sonbas.update();listeal();pencere.clipboard_clear();w_ayar=[]

def secimiptal(event):#tek aracın seçimini iptal et
	global secilen,secis,araçliste,kursorlar
	w=event.widget
	if w in secilen:
		i=secilen.index(w)
		wi=araçliste.index(w)
		w["cursor"]=kursorlar[wi]
		# wi=secilen.index(w);secilen[wi]["cursor"]="arrow"
		del secilen[i];secis[i].destroy();del secis[i]
	if len(secilen)==1: seksra["state"]="enabled"
def ilkform():#ilk formu oluştur
	global sonbas,fr
	ad=formadal()
	fr=Toplevel(pencere,takefocus=True,name=ad,relief="solid");fr.transient(pencere)
	fr.geometry("500x400+340+140");fr.title("form1")
	sonbas=fr
	bağla([sonbas])
	# fr.bind("<Button-1>",adal)
	# fr.bind("<Configure>",geoyaz);fr.bind("<Control-Button-3>",secimiptal)
	# fr.bind("<Key>",tushareket);fr.bind("<Alt-Enter>",faresec)
	# fr.bind("<Motion>",farehesap)
	fr.protocol('WM_DELETE_WINDOW',kapat)
	fr.update();ozyaz()


def arlbal(event=None):#sağdaki araç listesi için
	global sonbas
	sn=arlb.curselection()[0]
	sn=arlb.get(sn)#tıklanan aracın adını al
	ar=sn.split("--")[0];ad=""
	p=pencere.winfo_children()
	for i in p:#seçilen ada uyan aracı bulmak için formları tara
		a=i.winfo_children()
		for n in a:
			if n.winfo_class()=="Frame" and len(n.winfo_children())>1:
				ln1=n.winfo_children()[0];ln2=n.winfo_children()[1];ad1=ln1.winfo_name();ad2=ln2.winfo_name()
				if ad1==ar or ad2==ar:ad=ar;break
			else:
				if n.winfo_name()==ar:
					ad=ar
					break
		if ar==ad:
			sonbas=n;teksec(event)
			for p in pencere.winfo_children():p.lift()
			return

def tabsec(event=None):#tab sırasını ayarla
	global sonbas,kaydedildi,araçliste
	kaydedildi=False
	isim=sonbas.winfo_name()#tıklanan aracın adı
	sra=int(seksra.get())# sekme no.
	arlbdiz=[];diz1=[]
	for a in range(arlb.size()):
		nad=arlb.get(a).strip()
		n0=arlb.get(a).split("--")[0];n1=arlb.get(a).split("--")[1]
		if n1==" yok":diz1.append(nad);continue
		arlbdiz.append(n0)#araç listesindeki isimler
	if isim!=arlbdiz[sra]:#ismi yeni sırasına sok
		arlbdiz.remove(isim)
		arlbdiz.insert(sra,isim)
	arlbdiz.extend(diz1)
	arlb.delete(0,END)
	# print(arlbdiz,diz1,sep="\n")
	for a in arlbdiz:
		if " yok" not in a:
			arlb.insert(END,a+"--"+str(arlbdiz.index(a)));continue
		arlb.insert(END,a)

def devam():#önceki projeden devam et.
	global pencere,sonbas,ipu,sor,resimyol
	kapat()
	ds=open(ana_dizin+"/sonyol","r");fl=ds.read().strip()
	adres.delete(0,END);adres.insert(END,fl)#dosya yolunu al
	yl=fl.rsplit("/",1)[0]
	if not os.path.exists(yl):
		cevap=tkinter.messagebox.askyesno("Uyarı!",yl+"\n\nBöyle bir proje yok!\nBaşka bir dosya ya da proje açmak ister misiniz?")
		if cevap==True:
			ac();return
		else:
			sys.exit()
	os.chdir(yl+"/");sys.path.append(yl)
	d=os.path.splitext(os.path.basename(fl))[0]
	if d in sys.modules:
		del (sys.modules[d])
	gel=importlib.import_module(d)
	ch=gel.pencere.winfo_children()
	for i in ch:#Toplevel'ın her biri
		bağla([i])
		# i.bind("<Button-1>",adal);i.bind("<Control-Button-3>",secimiptal)
		# i.bind("<Key>",tushareket);i.bind("<Alt-Enter>",faresec)
		# i.bind("<Motion>",farehesap);i.bind("<Control-c>",kopyala)
		# i.bind("<Control-v>",kopyala);i.bind("<ButtonRelease-1>",farehesap)
		for a in (i.winfo_children()):#Toplevel üzerindeki nesneler
			adet=len(a.winfo_children())#arlb.insert(END,a.winfo_name()+"--"+str(sy))
			if adet>0:a=a.winfo_children()[adet-1]
			bağla([a])
			# a.bind("<Button-1>",adal);a.bind("<Control-Button-1>",sec);a.bind("<Button-1>",teksec)
			# a.bind("<B1-Motion>",yerdeg);a.bind("<Shift-Button-1>",sec)
			# a.bind("<Shift-B1-Motion>",harkop)
			# a.bind("<Shift-ButtonRelease-1>",kopya2)
	pencere=gel.pencere;ipu=gel.ipuclar;resimyol=gel.resimyol#;print resimyol
	try:
		diz=[]
		for n in enumerate(gel.tabsr):
			if n[1]["takefocus"]==0:
				diz.append(n[1].winfo_name()+"-- yok");continue
			arlb.insert(END,n[1].winfo_name()+"--"+str(n[0]))
		for ar in diz:arlb.insert(END,ar)
		syok=str(arlb.get(0,END)).count("yok")
		seksra["values"]=list(range(arlb.size()-syok))
	except Exception as ex:
		sy=0#;print(ex.args[0])
		for a in (i.winfo_children()):#Toplevel üzerindeki nesneler
			arlb.insert(END,a.winfo_name()+"--"+str(sy))
			sy+=1
		seksra["values"]=list(range(arlb.size()))
	ch[0].focus();sonbas=ch[0];topozyaz()
	listeal()

def yatayeşitle():#yatay aralıkları eşitle
	global secilen,secis
	# print(sonbas.winfo_name())#bununla da ayrılabilir
	seç=[];secis2=[];u=len(secilen)
	if u<3:return
	sol=[];gen=[];genler=[]#x ve genişlik değerleri. İlk-son araçlar yerinde
	for w in range(0,u):
		sol.append(int(secilen[w].place_info()["x"]))
		gen.append(int(secilen[w].place_info()["width"]))
#secilen dizisi sırasız olabilir, önce soldan sağa sıraya sok
	sollar=list(sol);sollar.sort()
	for i in range(u):
		seç.append(secilen[sol.index(sollar[i])])#seçilenler soldan sağa
		secis2.append(secis[sol.index(sollar[i])])#seçim işaretleri soldan sağa
		genler.append(gen[sol.index(sollar[i])])#genişlikler soldan sağa
	enbüyüksol=max(sollar);enazsol=min(sollar)#en sağ ve en soldakilerin x değeri
	aralıklar=0;x1=0
	for g in range(1,u-1):aralıklar+=genler[g]
	solfark=int((enbüyüksol-enazsol-genler[0]-aralıklar)/(u-1))
	for i in range(1,u-1):
		x=x1+genler[0]+sollar[0]+solfark*i
		seç[i].place_configure(x=x);secis2[i].place_configure(x=x-5)
		x1+=genler[i]

def dikeyeşitle():#dikey aralıkları eşitle
	global secilen,secis
	seç=[];secis2=[];u=len(secilen)
	if u<3:return
	ust=[];yuk=[];yukler=[]#y ve yükseklik değerleri. İlk-son araçlar yerinde
	for w in range(0,u):
		ust.append(int(secilen[w].place_info()["y"]))
		yuk.append(int(secilen[w].place_info()["height"]))
#secilen dizisi sırasız olabilir, önce üstten alta sıraya sok
	ustler=list(ust);ustler.sort()
	for i in range(u):
		seç.append(secilen[ust.index(ustler[i])])#seçilenler üstten alta
		secis2.append(secis[ust.index(ustler[i])])#seçim işaretleri üstten alta
		yukler.append(yuk[ust.index(ustler[i])])#yükseklikler üstten alta
	enbüyükust=max(ustler);enazust=min(ustler)#en üst ve altın y değeri
	aralıklar=0;y1=0
	for g in range(1,u-1):aralıklar+=yukler[g]
	ustfark=int((enbüyükust-enazust-yukler[0]-aralıklar)/(u-1))
	for i in range(1,u-1):
		y=y1+yukler[0]+ustler[0]+ustfark*i
		seç[i].place_configure(y=y);secis2[i].place_configure(y=y-5)
		y1+=yukler[i]

def listeal():
	global araçliste,sayliste,kursorlar
	araçliste,sayliste,kursorlar=[],[],[]
	syy=pencere.winfo_children()
	harictut=["araclar","ust","arlb"]
	for ww in syy:#formlardaki araçların isimleri
		fa=ww.winfo_name()
		if fa in harictut or fa.isdigit()==True: continue
		sayliste.append(fa)
		wwp=ww.place_slaves()
		for a in wwp:
			arc=a["cursor"]
			arad=a.winfo_name();
			arsnf=a.winfo_class()
			if arsnf=="Frame":
				cd=a.winfo_children()
				if len(cd)>1:
					ar=a.winfo_children()[-1]
					arc=a.winfo_children()[-1]["cursor"]
					arad=a.winfo_children()[-1].winfo_name()
					a=ar
			araçliste.append(a)#sadece araçların kendileri, formlar yok!
			sayliste.append(arad)#formlar dahil isimler, sayaç için
			kursorlar.append(arc)#kursorlar için
	araçliste2=[]
	for a in syy:araçliste2.extend(a.winfo_children())
	n=tuple(set(araçliste2)-set(araçliste))
	for i in n:araçliste.append(i)
	# print(araçliste)

def aralıklar(z):
	global secilen,secis,kaydedildi
	sıra=[];kaydedildi=False
	for w in secilen:#önce x değerlerine göre sırala
		sl=int(w.place_info()["x"]);ut=int(w.place_info()["y"])
		sıra.append((sl,ut))
	seco=list(sıra)#orijinal liste
	sıra.sort()#sıralanmış liste
	secsra=[secilen[seco.index(x)] for x in sıra]#soldan sağa seçilenler
	secissra=[secis[seco.index(x)] for x in sıra]#soldan sağa seçim işaretleri
	sayaç=1
	if z=="d0":  #yatay aralıkları azalt
		for ni,i in enumerate(secsra[1:],1):
			i.place_configure(x=sıra[ni][0]-sayaç);si=secissra[ni]
			si.place_configure(x=int(si.place_info()["x"])-sayaç)
			sayaç+=1
	sayaç=1
	if z=="d1":  #yatay aralıkları arttır
		for ni,i in enumerate(secsra[1:],1):
			i.place_configure(x=sıra[ni][0]+sayaç);si=secissra[ni]
			si.place_configure(x=int(si.place_info()["x"])+sayaç)
			sayaç+=1
	sayaç=1
	if z=="d2":  #düşey aralıkları azalt
		for ni,i in enumerate(secsra[1:],1):
			i.place_configure(y=sıra[ni][1]-sayaç);si=secissra[ni]
			si.place_configure(y=int(si.place_info()["y"])-sayaç)
			sayaç+=1
	sayaç=1
	if z=="d3":  #düşey aralıkları arttır
		for ni,i in enumerate(secsra[1:],1):
			i.place_configure(y=sıra[ni][1]+sayaç);si=secissra[ni]
			si.place_configure(y=int(si.place_info()["y"])+sayaç)
			sayaç+=1
#*****************fonksiyonların sonu********************************************


#***********************araçlar penceresi öğeleri*********************************
#****araç oluşturma için simgeler******
x,y=2,30
resimliste=["button.png","label.png","textview.png","entry.png","list.png","checkbutton.png","radiobutton.png","viewport.png","image.png","scrolledwindow.png","spinbutton.png","hpaned.png","form2.png","sctext2.png","combobox1.png","list3.png","vscrollbar.png","menü.png","aboutdialog.png"]
textliste=["Button","Label","Text","Entry","Listbox","Checkbutton","Radiobutton","Frame","Canvas","Scale","Spinbox","PanedWindow","Toplevel","ScrolledText","Combobox",					 "ScrolledList","Scrollbar","Menü","Message"]
ar2=(Button,Label,Text,Entry,Listbox,Checkbutton,Radiobutton,Frame,Canvas,Scale,Spinbox,
		 PanedWindow,Toplevel,ScrolledText,Combobox,ScrolledList,Scrollbar,Menu,Message)
for i in resimliste:#simge oluşturma döngüsü
	ri=resimliste.index(i)
	d="ikon/"+i;t=textliste[ri]
	resim=ImageTk.PhotoImage(file=d)
	dg=Button(araclar,bg="lightgreen",image=resim,text=t,command=lambda m=ar2[ri]:yap(m))
	dg.image=resim;dg.place(x=x,y=y)
	wcktooltips.register(dg,t)
	x+=27
	if x>250:x=3;y+=35
# etiketler************************
par=Label(araclar,text="Pencere araçları",bg="Cyan",font="Ubuntu 12")
par.pack(side=TOP,anchor=N,padx=5,pady=2,fill=X)
ozd=Label(araclar,text="Araç özellikleri",width=27,font="Ubuntu12",bg="#d8e374",fg="dark blue")
ozd.place(x=1,y=100)
#*******scale aracı-listeyi kaydırmak için*************
vs=Scale(araclar,length=570,to=1200,showvalue=0,activebackground="red",command=har)#kaydırma çubuğu
vs.place(x=250,y=125)
vs.bind("<Button-4>",tekerlek)#fare tekerleği kabloya doğru çevriliyor---liste--->aşağı
vs.bind("<Button-5>",tekerlek)#fare tekerleği bana doğru çevriliyor--liste--->yukarı
f.bind("<Button-4>",tekerlek);f.bind("<Button-5>",tekerlek)#tekerlek liste üzerinde çevriliyor

#*********** üst pencere---araç çubuğu öğeleri***************************
ust=Toplevel(name="ust")#üst pencere
#ust.geometry("776x30+193+108")
ust.geometry("1345x30+5+5")
ust.title("Araç Çubuğu");ust.update()#;print(ust.winfo_width(),type(ust.winfo_width()))
tf=Frame(ust,width=ust.winfo_width(),height=27,bg="green")#toolbar aracı
tf.place(x=1,y=1)
#resimler
komut=[ac,kapatsor,kaydet,farkkaydet,sil,menüsil,ck]
resimler=["aç2.png","kapat.png","save2.png","save3.png","delete4.png","mensl2.png","exit2.png"]
x=3
ipliste=["varolan dosyayı aç","bu dosyayı kapat","formu kaydet","farklı kaydet","Seçilen aracı sil","Menüyü sil.Önce pencereyi seçin.","Programdan çık"]
for a in range(7):
	r="ikon/"+resimler[a];resim=ImageTk.PhotoImage(file=r)
	sl=Button(tf,padx=2,pady=3,compound="left",image=resim,command=komut[a])
	sl.image=resim;sl.place(x=x,y=2)
	wcktooltips.register(sl,ipliste[a])
	x+=26

#hizalama*******************
ikonliste=["uste hizala.png","alta hizala.png","sola hizala.png","saga hizala.png"]
dugmeisimliste=["us","alt","sol","sag"]
wckliste=["Üste hizala","Alta hizala","Sola hizala","Sağa hizala"]
bx=[280,305,330,355]#düğme "x" değerleri--mecbur kaldım!

ikont=["","","",""]
for a in ikonliste:#hizalama düğmeleri
	r="ikon/"+a;resim=ImageTk.PhotoImage(file=r)
	ir=ikonliste.index(a)
	ad=dugmeisimliste[ir];wckad=wckliste[ir]
	met=ikont[ir]
	b1=Button(tf,text=met,padx=1,pady=0,compound="right",image=resim,repeatdelay=15,repeatinterval=50,name=ad,command=lambda m=dugmeisimliste[ir]:dugmeebat(m))
	b1.image=resim;b1.place(x=bx[ir],y=2)
	wcktooltips.register(b1,wckad)

#eşitleme düğmeleri
r="ikon/yatay.png"
resim=ImageTk.PhotoImage(file=r)
eşyat=Button(tf,padx=1,pady=0,text="",compound="left",image=resim,name="xyatay",
						 command=yatayeşitle)
eşyat.image=resim;eşyat.place(x=400,y=2,width=24,height=24)
wcktooltips.register(eşyat,"yatay aralıkları eşitle")
r="ikon/dikey.png"
resim=ImageTk.PhotoImage(file=r)
eşdik=Button(tf,padx=1,pady=0,text="",compound="left",image=resim,name="ydikey",command=dikeyeşitle)
eşdik.image=resim;eşdik.place(x=425,y=2,width=24,height=24)
wcktooltips.register(eşdik,"dikey aralıkları eşitle")

#yatay ve dikey aralıkları arttırma-azaltma
resimler=["yatazalt.png","yatarttır.png","dikazalt.png","dikarttır.png"];xf=0
ipuçları=["yatay aralıkları azalt","yatay aralıkları arttır","dikey aralıkları azalt","dikey aralıkları arttır"]
isimlerd=["d0","d1","d2","d3"]
for b in range(4):
	r="ikon/"+resimler[b]
	resim=ImageTk.PhotoImage(file=r)
	d=Button(tf,padx=1,pady=0,text="",compound="left",image=resim,repeatdelay=80,repeatinterval=25,name=isimlerd[b])
	d.image=resim;d.place(x=450+xf,y=2,width=24,height=24);xf+=25
	wcktooltips.register(d,ipuçları[b])
	d["command"]=lambda z=isimlerd[b]:aralıklar(z)

#en-boy ayarlama*************
wckliste=["Aracın enini ayarla (piksel)","Aracın yüksekliğini ayarla (piksel)"]
tl=["genişlik","yükseklik"];x=908
for a in range(2):
	lb=Label(tf,text=tl[a]);lb.place(x=x,y=1,width=60,height=24)
	wcktooltips.register(lb,wckliste[a])
	x+=130
spnen=Spinbox(tf,relief="flat",from_=0,to=1300,fg="blue",buttonbackground="red",font="ubuntu 10",repeatdelay=80,repeatinterval=25,command=enveboy)
spnen.place(x=970,y=1,width=50,height=24);spnen.bind("<Return>",enveboy);spnen.bind("<FocusOut>",enveboy)
spnyuk=Spinbox(tf,relief="flat",from_=0,to=1300,fg="blue",buttonbackground="red",font="ubuntu 10",repeatdelay=80,repeatinterval=25,command=enveboy)
spnyuk.place(x=1100,y=1,width=50,height=24);spnyuk.bind("<Return>",enveboy);spnyuk.bind("<FocusOut>",enveboy)

#hareket etiketleri ve düğmeleri***********************
x=1178
for a in range(2):
	tl=["x=","y="];wckad=["pencerenin sol kenarından mesafe (piksel)","pencerenin üst kenarından mesafe (piksel)"]
	lb=Label(tf,text=tl[a]);lb.place(x=x,y=1,width=20,height=24)
	wcktooltips.register(lb,wckad[a])
	x+=90
spnx=Spinbox(tf,relief="flat",from_=0,to=300,fg="blue",buttonbackground="red",font="ubuntu 10",repeatdelay=70,repeatinterval=25,command=konumx)
spnx.place(x=1200,y=1,width=50,height=24);spnx.bind("<Return>",konumx);spnx.bind("<FocusOut>",konumx)
spny=Spinbox(tf,relief="flat",from_=0,to=300,fg="blue",buttonbackground="red",font="ubuntu 10",repeatdelay=80,repeatinterval=25,command=konumy)
spny.place(x=1290,y=1,width=50,height=24);spny.bind("<Return>",konumy);spny.bind("<FocusOut>",konumy)
#form ve tasarım düğmeleri
r="ikon/run.png";resim=ImageTk.PhotoImage(file=r)
çal=Button(tf,padx=1,pady=0,image=resim,command=çalıştır);çal.place(x=600,y=2)
wcktooltips.register(çal,"programı çalıştır");çal.image=resim

r="ikon/tasarla.png";resim=ImageTk.PhotoImage(file=r)
dk=Button(tf,padx=1,pady=0,image=resim,command=tasarla);dk.place(x=625,y=2)
wcktooltips.register(dk,"program kodlarını gör");dk.image=resim

r="ikon/form.png";resim=ImageTk.PhotoImage(file=r)
df=Button(tf,padx=1,pady=0,image=resim,state="normal",command=kodgir);df.place(x=650,y=2)
wcktooltips.register(df,"form kodlarını gör")

#kopyalama
ko=Button(tf,text="kopyala",bd=0,fg="red",relief="flat",padx=0,command=kopyala)
ko.place(x=700,y=2,height=24)
wcktooltips.register(ko,"işaretlenen araçları, tıklanan forma yapıştırır.\nÖnce araçları seçip -kopyala- düğmesine basın.")

#tab sırası için kombo
ket=Label(tf,text="Sekme sırası:");ket.place(x=755,y=2,height=24)
seksra=Combobox(tf,width=4);seksra.place(x=843,y=1,height=24)


#------------------ pencere araçları sabit değerler----------------------------
kursor=(
"bottom_right_corner,bottom_left_corner,bottom_side,top_side,left_side,right_side,top_left_corner,top_right_corner")
normkursor='arrow,circle,clock,cross,dotbox,exchange,fleur,hand2,heart,man,mouse,pirate,plus,shuttle,sizing,spider,spraycan,star,target,tcross,trek,watch,xterm'
sabit={"anchor":"center,n,e,w,s,ne,nw,se,sw","justify":"center,left,right",
			 "relief":'flat,raised,sunken,ridge,groove,solid',
			 "overrelief":'flat,raised,sunken,ridge,groove,solid',
			 "state":'normal,active,disabled',
			 "selectmode":'single,browse,multiple,extended',
			 "default":"disabled,normal,active",
			 "cursor":normkursor,"compound":'none,left,right,bottom,top,center',"indicatoron":"1,0",
			 "direction":"below,above,left,right",
			 "takefocus":"0,1","activestyle":"dotbox,underline,none",
			 "orient":"vertical,horizontal","showhandle":"0,1","sashcursor":normkursor,"window icon":"error,gray75,gray50,gray25,gray12,hourglass,info,questhead,question,warning","resizable":"1-1,1-0,0-1,0-0","overrideredirect":"1,0","wrap":"char,word"}
#************pencere araçlarının listesi*************************************
#***takefocus=1 olanların sekme sırası********
etkarlb=Label(text="Sekme Sırası",width=20);etkarlb.pack(anchor=SE)
arlb=Listbox(pencere,bg="#13d693",fg="blue",font="ubuntu 10",height=15,name="arlb")
arlb.pack(anchor=SE)
arlb.bind("<ButtonRelease-1>",arlbal)
#
#*********************en son, ilk formu oluştur********************************
# ilkform()
#***********************************************************************
os.chdir("/home/"+kul+"/Masaüstü/")

def göster(ad):
	global sonbas
	fr=Toplevel(pencere,takefocus=True,name=ad,relief="solid");fr.transient(pencere)
	fr.geometry("500x400+340+140");fr.title("form1")
	sonbas=fr
	bağla([sonbas])
	# fr.bind("<Button-1>",adal)
	# fr.bind("<Configure>",geoyaz);fr.bind("<Control-Button-3>",secimiptal)
	# fr.bind("<Key>",tushareket);fr.bind("<Alt-Enter>",faresec)
	# fr.bind("<Motion>",farehesap)
	fr.protocol('WM_DELETE_WINDOW',kapat);sonbas=fr
	fr.update();ozyaz()


def yeniol():#yeni proje klasörü ve proje dosyalarını oluştur
	e=sor.winfo_children()[0]
	prad=(e.get())
	if not os.path.exists(prad):#program dosyası oluşturuluyor
		os.makedirs(prad);sor.destroy()
		os.chdir("/home/"+kul+"/Masaüstü/"+prad)
		dsad=prad+"prg.py";frmad=prad+"form.py";frmanaad=(frmad.split(".")[0])
		ds=open(dsad,"w")#çalıştırılabilir dosya oluşturuluyor
		ds.write("#!/usr/bin/env python3\n#-*- coding: utf8 -*-\n")
		ds.write("#********* yukarıdaki değerleri değiştirmeyiniz ***************\n")
		ds.write("import getpass,sys,os\n")
		ds.write('from '+frmanaad+' import*'+'\n')
		ds.write("kul=getpass.getuser()\nsys.path.append(os.getcwd())\n")
		ds.write("#program_adı:"+prad+"prg.py\n")
		ds.write("\n"*25);ds.write("\n#******* lütfen silmeyiniz **********");ds.write("\n")
		ds.write("p=pencere.winfo_parent()\nwn=pencere._nametowidget(p);wn.withdraw()")
		ds.write('\nmainloop()\n')
		ds.close()
		#form dosyası oluşturuluyor
		ad=formadal()
		yz="#!/usr/bin/env python3\n#-*- coding: utf8 -*-\nfrom tkinter import*\n"
		yz+="from tkinter.scrolledtext import ScrolledText\nfrom tkinter.scrolledlist import*\n"
		yz+="from tkinter.ttk import Combobox\nfrom tkinter import wcktooltips\npencere=Tk()\n"
		yz+=ad+'=Toplevel(pencere,{"bd": "0", "bg": "#d960d9", "highlightthickness": "0", "relief": "solid", "highlightcolor": "#000000", "borderwidth": "0", "background": "#d960d9", "pady": "0", "padx": "0", "takefocus": "1", "highlightbackground": "#d9d9d9"},name='+"'"+ad+"')\n"
		yz+=ad+".geometry('500x400+359+171')\n";yz+=ad+".title('ana form')"
		# fr=Toplevel(yz)
		yz+="\nresimyol=[]\nipuclar={}\npencere.withdraw()"
		dr=open(frmad,"w");dr.write(yz);dr.close()
		yl=("/home/"+kul+"/Masaüstü/"+prad+"/"+frmad)
		adres.delete(0,END);adres.insert(END,yl)
		ds=open(ana_dizin+"/sonyol","w")
		ds.write(yl)
		ds.close()#son dosyanın yolunu ana program dizinine yaz.
		listeal()
	else:
		tkinter.messagebox.showwarning("Uyarı!","Bu isimde bir klasör zaten var!!")
		sor.lift();sor.setfocus()
		return
	göster(ad);pencere.update()

def yeniproje():
	global sor
	os.chdir("/home/"+kul+"/Masaüstü/")
	sor=Toplevel(pencere);sor.geometry("300x130+360+160");sor.title("proje adını girin")
	sr=Entry(sor,width=15);sr.place(x=10,y=10);sr.focus()
	nt=Label(sor,justify=LEFT,text="Projeniz Masaüstünde oluşturulacaktır.\nYerini daha sonra değiştirebilirsiniz.")
	nt.place(x=10,y=40)
	bt=Button(sor,text="Tamam",command=yeniol).place(x=10,y=80)

def boşaç():
	ilkform()


if secenek=="1": boşaç()
if secenek=="2": ac()
if secenek=="3": yeniproje()
if secenek=="4": devam()
syok=str(arlb.get(0,END)).count("yok")
seksra["values"]=list(range(arlb.size()-syok))
seksra.set(0)#tab sırasını göster
seksra.bind("<<ComboboxSelected>>",tabsec)
sbky=["activebackground","activerelief","background","bg","borderwidth","bd",
   "command","cursor", "elementborderwidth","highlightbackground","highlightcolor","highlightthickness","jump","orient","relief","repeatdelay","repeatinterval","takefocus","troughcolor"]


mainloop()
